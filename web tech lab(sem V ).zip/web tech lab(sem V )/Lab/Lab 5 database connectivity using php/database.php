<? php

$user='root';
$pass='';
$dbz='test';
$dbz= new mysqli('localhost',$user,$pass,$dbz);

if(insert($_POST['Submit']))
{
 $Name=$_POST['name'];
 $Roll_no=$_POST['roll_no'];
 $Gender=$_POST['gender'];
 
 if(mysqli_query($dbz,"insert into Reg(name,roll_no,gender) values('$Name','$Roll_no','Gender'); "))
 {
  echo "Data is Accepted";
  }
  
  mysqli_close($dbz);
  }
  
  ?>