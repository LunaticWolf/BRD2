
var firstplace = Math.ceil(Math.random() * 9)+ '';
var secondplace = Math.ceil(Math.random() * 9)+ '';
var thirdplace = Math.ceil(Math.random() * 9)+ '';
 
var captchacode = firstplace + secondplace + thirdplace;
document.getElementById("captchaCode").value = captchacode;
document.getElementById("captchaShowArea").innerHTML = captchacode;
// Validate the Entered input agonist the generated captcha code by function
function ValidCaptcha(){
var genText = removeSpaces(document.getElementById('captchaCode').value);
var inputText = removeSpaces(document.getElementById('captcha').value);
if (genText == inputText){
return true;
}else{
return false;
}
}
// Remove the spaces from the entered and generated code
function removeSpaces(string){
return string.split(' ').join('');
}


function checkFormSubmit(){
        var err = '';        
        var firstname = document.getElementById('firstName').value;
        if(firstname !='' ){
            err += '';
            document.getElementById('firstNameErr').innerHTML = '';
        }else{
            err += 'error';
            document.getElementById('firstNameErr').innerHTML = 'Please Fill Name';
        }        
        var email = document.getElementById('emailId');
        var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
         if (filter.test(email.value)) {
            err += '';
            document.getElementById('emailIdErr').innerHTML = '';
         }else{
            err += 'error';
            document.getElementById('emailIdErr').innerHTML = 'Please Fill Valid Email';
        }        
        var captchaform = document.getElementById('captcha').value;
        if(captchaform !='' && ValidCaptcha()){
            err += '';
            document.getElementById('captachacodeErr').innerHTML = '';
        }else{
            err += 'error';
            document.getElementById('captachacodeErr').innerHTML = 'Please Fill Valid Captcha';
        }   
        if(err == '')
        {
            return true;
        }else{
            return false;
        }
    } 