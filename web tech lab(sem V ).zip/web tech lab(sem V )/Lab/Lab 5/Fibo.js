function Fibo()
{

 this.Lfibi = function(n) 
              {
                var a = 0, b = 1, c = 1;
                for(var i = 2; i <= n; i++) 
                {
                  c = a + b;
                  a = b;
                  b = c;
                }
                  return c;
              };


 this.Rfibi =  function(n)
               { 
                if(n<=2)
                     {
                     	 return 1;
                     }

                else
                	 {
                         return this.Rfibi(n-1) + this.Rfibi(n-2);
                	 }

               };
]
