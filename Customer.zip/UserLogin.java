package com.nu.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;





@Entity
@Table(name="USERLOGINDATA")
public class UserLogin 
{

	
	
    //Fields...........................................................................................
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	@Column(name="user_id" , nullable=false ,  unique=true)
	private int userID;
	
	@Column(name="user_name", nullable=false , unique=true)
	private String userName;
	
	@Column(name="user_password" ,nullable=false)
	private String userPassword;
	
	@Column(name="user_role", nullable=false)
	private String userRole;
	
	
	
	
	
	
	
	//Getters....................................................................................................
	public int getUserID() {
		return userID;
	}
	public String getUserName() {
		return userName;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public String getUserRole() {
		return userRole;
	}
	
	
	
	
	
	//Setters......................................................................................................
	
	public void setUserID(int userID) {
		this.userID = userID;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}
	
	
	
	
	
	
	//Constructor........................................................................................................
	public UserLogin(int userID, String userName, String userPassword, String userRole) {
		super();
		this.userID = userID;
		this.userName = userName;
		this.userPassword = userPassword;
		this.userRole = userRole;
	}
	
	
	
	public UserLogin(int userID, String userName, String userRole) {
		super();
		this.userID = userID;
		this.userName = userName;
		this.userRole = userRole;
	}
	
	
	
	
	//toString........................................................................................................... 
	@Override
	public String toString() {
		return "UserLogin [userID=" + userID + ", userName=" + userName + ", userPassword=" + userPassword
				+ ", userRole=" + userRole + "]";
	}
	
	

}
