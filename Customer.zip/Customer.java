package com.nucleus.nsbt.batch5.brd2.modellayer;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
	@Table(name="")
	public class Customer 
	{
		@Id
		@GeneratedValue(strategy=GenerationType.SEQUENCE) 
		private int customerId;
	
		@Column(name="customer_code", nullable = false, unique=true)
		private String customerCode;
		
		@Column(name="customer_name", nullable = false, unique=true)
		private String customerName;
		
		@Column(name="customer_address1", nullable = false, unique=true)
		private String customerAddress1;
		
		@Column(name="customer_address2")
		private String customerAddress2;
		
		@Column(name="customer_pincode", nullable = false, unique=true)
		private String customerPinCode;
		
		@Column(name="customer_email", nullable = false, unique=true)
		private String customerEmail;
		
		@Column(name="customer_contact_number", nullable = false, unique=true)
		private String customerContactNumber;
		
		@Column(name="customer_primary_contact_person", nullable = false)
		private String customerPrimaryContactPerson;
		
		@Column(name="customer_record_status", nullable = false, unique=true)
		private String customerRecordStatus;
		
		@Column(name="customer_flag_status", nullable = false, unique=true)
		private String customerFlagStatus;
		
		@Column(name="created_date", nullable = false)
		private String createdDate;
		
		@Column(name="created_by", nullable = false)
		private String createdBy;
		
		@Column(name="modified_date")
		private String modifiedDate;
		
		@Column(name="modified_by")
		private String modifiedBy;
		
		@Column(name="authorized_date")
		private String authorizedDate;

		@Column(name="authorized_by")
		private String authorizedBy;

		
		
		
		
		
		
		
		//getters and setters
		public int getCustomerId() {
			return customerId;
		}
		public void setCustomerId(int customerId) {
			this.customerId = customerId;
		}

		
		public String getCustomerCode() {
			return customerCode;
		}

		public void setCustomerCode(String customerCode) {
			this.customerCode = customerCode;
		}

		
		public String getCustomerName() {
			return customerName;
		}

		public void setCustomerName(String customerName) {
			this.customerName = customerName;
		}

		
		public String getCustomerAddress1() {
			return customerAddress1;
		}

		public void setCustomerAddress1(String customerAddress1) {
			this.customerAddress1 = customerAddress1;
		}

		
		public String getCustomerAddress2() {
			return customerAddress2;
		}

		public void setCustomerAddress2(String customerAddress2) {
			this.customerAddress2 = customerAddress2;
		}

		
		
		public String getCustomerPinCode() {
			return customerPinCode;
		}

		public void setCustomerPinCode(String customerPinCode) {
			this.customerPinCode = customerPinCode;
		}

		
		
		public String getCustomerEmail() {
			return customerEmail;
		}

		public void setCustomerEmail(String customerEmail) {
			this.customerEmail = customerEmail;
		}

		
		
		public String getCustomerContactNumber() {
			return customerContactNumber;
		}

		public void setCustomerContactNumber(String customerContactNumber) {
			this.customerContactNumber = customerContactNumber;
		}

		
		
		public String getCustomerPrimaryContactPerson() {
			return customerPrimaryContactPerson;
		}

		public void setCustomerPrimaryContactPerson(String customerPrimaryContactPerson) {
			this.customerPrimaryContactPerson = customerPrimaryContactPerson;
		}

		
		
		public String getCustomerRecordStatus() {
			return customerRecordStatus;
		}

		public void setCustomerRecordStatus(String customerRecordStatus) {
			this.customerRecordStatus = customerRecordStatus;
		}

		
		
		public String getCustomerFlagStatus() {
			return customerFlagStatus;
		}

		public void setCustomerFlagStatus(String customerFlagStatus) {
			this.customerFlagStatus = customerFlagStatus;
		}

		
		
		public String getCreatedDate() {
			return createdDate;
		}

		public void setCreatedDate(String createdDate) {
			this.createdDate = createdDate;
		}

		
		
		public String getCreatedBy() {
			return createdBy;
		}

		public void setCreatedBy(String createdBy) {
			this.createdBy = createdBy;
		}

		
		
		public String getModifiedDate() {
			return modifiedDate;
		}

		public void setModifiedDate(String modifiedDate) {
			this.modifiedDate = modifiedDate;
		}

		
		
		public String getModifiedBy() {
			return modifiedBy;
		}

		public void setModifiedBy(String modifiedBy) {
			this.modifiedBy = modifiedBy;
		}

		
		
		public String getAuthorizedDate() {
			return authorizedDate;
		}

		public void setAuthorizedDate(String authorizedDate) {
			this.authorizedDate = authorizedDate;
		}

		
		
		public String getAuthorizedBy() {
			return authorizedBy;
		}

		public void setAuthorizedBy(String authorizedBy) {
			this.authorizedBy = authorizedBy;
		}
		
		
		
		
		
		//Constructor
		public Customer(int customerId, String customerCode, String customerName, String customerAddress1,
				String customerAddress2, String customerPinCode, String customerEmail, String customerContactNumber,
				String customerPrimaryContactPerson, String customerRecordStatus, String customerFlagStatus,
				String createdDate, String createdBy, String modifiedDate, String modifiedBy, String authorizedDate,
				String authorizedBy) {
			super();
			this.customerId = customerId;
			this.customerCode = customerCode;
			this.customerName = customerName;
			this.customerAddress1 = customerAddress1;
			this.customerAddress2 = customerAddress2;
			this.customerPinCode = customerPinCode;
			this.customerEmail = customerEmail;
			this.customerContactNumber = customerContactNumber;
			this.customerPrimaryContactPerson = customerPrimaryContactPerson;
			this.customerRecordStatus = customerRecordStatus;
			this.customerFlagStatus = customerFlagStatus;
			this.createdDate = createdDate;
			this.createdBy = createdBy;
			this.modifiedDate = modifiedDate;
			this.modifiedBy = modifiedBy;
			this.authorizedDate = authorizedDate;
			this.authorizedBy = authorizedBy;
		}
		
		
		
		//Without ID and Date
		public Customer(String customerCode, String customerName, String customerAddress1, String customerAddress2,
				String customerPinCode, String customerEmail, String customerContactNumber,
				String customerPrimaryContactPerson, String customerRecordStatus, String customerFlagStatus,
				String createdBy) {
			super();
			this.customerCode = customerCode;
			this.customerName = customerName;
			this.customerAddress1 = customerAddress1;
			this.customerAddress2 = customerAddress2;
			this.customerPinCode = customerPinCode;
			this.customerEmail = customerEmail;
			this.customerContactNumber = customerContactNumber;
			this.customerPrimaryContactPerson = customerPrimaryContactPerson;
			this.customerRecordStatus = customerRecordStatus;
			this.customerFlagStatus = customerFlagStatus;
		}
		
		
		
		
		
		
		public Customer() {
			// TODO Auto-generated constructor stub
		}
		
		
		
		//To String
		@Override
		public String toString() {
			return "Customer [customerId=" + customerId + ", customerCode=" + customerCode + ", customerName="
					+ customerName + ", customerAddress1=" + customerAddress1 + ", customerAddress2=" + customerAddress2
					+ ", customerPinCode=" + customerPinCode + ", customerEmail=" + customerEmail
					+ ", customerContactNumber=" + customerContactNumber + ", customerPrimaryContactPerson="
					+ customerPrimaryContactPerson + ", customerRecordStatus=" + customerRecordStatus
					+ ", customerFlagStatus=" + customerFlagStatus + ", createdDate=" + createdDate + ", createdBy="
					+ createdBy + ", modifiedDate=" + modifiedDate + ", modifiedBy=" + modifiedBy + ", authorizedDate="
					+ authorizedDate + ", authorizedBy=" + authorizedBy + "]";
		}



		
		
		
		
		
		
}


