package com.nucleus.nsbt.batch5.brd2.controllerlayer;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import org.hibernate.SessionFactory;

import com.nucleus.nsbt.batch5.brd2.modellayer.HibernateSessionFactory.HibernateSessionFactory;


@WebListener
public class HibernateSessionFactoryListner implements ServletContextListener 
{

	private SessionFactory factory = null;
	
    public HibernateSessionFactoryListner() {}

 public void contextInitialized(ServletContextEvent sce)
     
    { 
    	factory = HibernateSessionFactory.getSessionFactory();
		sce.getServletContext().setAttribute("factorylistner", factory);    	
    }

	
   public void contextDestroyed(ServletContextEvent sce) 
    { 
    	sce.getServletContext().removeAttribute("factorylistner");
    	
		if(factory!=null)
			factory.close();
    	
    }
	
}
