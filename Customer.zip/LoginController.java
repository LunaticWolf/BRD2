package com.nu.LoginController;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.SessionFactory;

import com.nu.dao.LoginDao;
import com.nu.dao.LoginDbUtil;
import com.nu.model.UserLogin;


@WebServlet("/LoginController")
public class LoginController extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
	
	private SessionFactory factory = null;
	HttpSession httpSession=null;

	
	@Override
	public void init(ServletConfig config) throws ServletException 
	{
		super.init(config);
		factory = (SessionFactory) this.getServletContext().getAttribute("factory");
		
	}
  
    public LoginController() 
    {
        super();
  
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
	
		String theCommand = request.getParameter("Command");
		
		String page="welcome.jsp";
		
		switch(theCommand)
		{
		
		 
		case "Login": page="LoginPage.jsp";
		break;
		
		
		default: page="same page";
		/*case "SignUp": page="SignUp.jsp";
		break;*/
		
		
		
		}
		
		//dispatch page request
		requestDispatched(request, response, page);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{

		String theCommand = request.getParameter("Command");
		String page ="";
		
		switch(theCommand)
		{
		
		 
			case "Login": login(request, response);
			break;
			
			//case "SignUp": signup(request,response);
			//break;
		
		
		}
		
		
		
	}

	
    //Request Dispatcher
	private void requestDispatched(HttpServletRequest request, HttpServletResponse response, String page)
			throws ServletException, IOException 
	{
		RequestDispatcher requestDispatcher=request.getRequestDispatcher(page);	
		requestDispatcher.forward(request, response);
	}


	
	
	
	
	private void login(HttpServletRequest request, HttpServletResponse response) 
	{
		
		List<UserLogin> User = null;
		
		String username=request.getParameter("UserName");
		String password=request.getParameter("Password");
		
		//get H-session
		LoginDao dao = new LoginDbUtil(factory);
		
		User = dao.validate(username, password);
		
		HttpSession Session = request.getSession();
		request.setAttribute("UserLogged", User);
		
		
		//Dispatch to page with NavBar;
		String page = "welcome2.jsp";
		requestDispatched(request, response, page);
		
	}

}
