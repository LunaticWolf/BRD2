package com.nucleus.nsbt.batch5.brd2.modellayer;

import java.util.List;

public interface CustomerDao
{
   
	public List<Customer> getCustomers();


	public Customer addCustomer(Customer customer);
	public Customer updateCustomer(Customer customer);
	public Customer deleteCustomer(String theCustomerCode);
	public Customer getCustomerById(String theCustomerCode);
	

}