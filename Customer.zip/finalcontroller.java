package com.nucleus.nsbt.batch5.brd2.controllerlayer;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.SessionFactory;

import com.nucleus.nsbt.batch5.brd2.modellayer.Customer;
import com.nucleus.nsbt.batch5.brd2.modellayer.CustomerDao;
import com.nucleus.nsbt.batch5.brd2.modellayer.CustomerDbUtil;


@WebServlet("/CustomerController")
public class CustomerController extends HttpServlet
{
	
		private static final long serialVersionUID = 1L;

		private SessionFactory factory = null;
		HttpSession httpSession=null;

		
		@Override
		public void init(ServletConfig config) throws ServletException 
		{
			super.init(config);
			factory = (SessionFactory) this.getServletContext().getAttribute("factory");
			
		}
	       
	    
		//Default
	    public CustomerController()
	     {
	        super();
	     }



		
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
		{
		    String page;
			String Command=request.getParameter("theCommand");
		


            Switch(Command)
          	{

          		case "New":page = "/WEB-INF/jsp/NewRegistration.jsp";//AddPage
          	   	break;


          		case "SingleView":page = "/WEB-INF/jsp/viewone.jsp";//Ask-getID page
          	   	break;


		    	case "MultiView": listCustomer(request,response);
		    	break;

								  //To Page
								  //page = "/WEB-INF/jsp/viewall.jsp";//All record view Page



		    	case "Update": page = "/WEB-INF/jsp/update1.jsp";  //ask.page get id
		    	break;


		    	case"Delete":	page = "WEB-INF/jsp/DeleteUser.jsp"; //ask page get id
		    	break;


		    	case"LogOut": page = "/*End User Session Here*/"; //welcome page before login
		    	break;

          
            	default: page =" /WEB-INF/jsp/NewRegistration.jsp";//Navbar page
		

            }

            requestDispatched(request, response, page);

}
 




             //Request Dispatcher
		private void requestDispatched(HttpServletRequest request, HttpServletResponse response, String page)
				throws ServletException, IOException 
		{
			RequestDispatcher requestDispatcher=request.getRequestDispatcher(page);	
			requestDispatcher.forward(request, response);
		}







	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
		{
			String page="welomepage.jsp";
			String Command=request.getParameter("theCommand");


			Switch(Command)
			{
				
				case"New": addCustomer(request,response);
				break;

				
				case"SingleView": singleCustomer(request,response);
				break;               

				
				case"MultiView": listCustomer(request,response);//multiCustomer(request,response);
				break;

				
				case"Update": updateCustomer(request,response);
				break;

				case"Load": loadCustomer(request,response);
				break;

				
				case"Delete": deleteCustomer(request,response);
				break;

				
				case"Logout": logoutCustomer(request,response);
				break;


				//change it
				default: MultiCustomer(request,response);



			}

		}





//View ALL Customers--------------------------------------------------------------------------

private void listCustomer(HttpServletRequest request,
			HttpServletResponse response) throws SQLException, ServletException, IOException 
	{
								
		
	//create list
        List<Customer> customers = null;
		

		
        //get H-Session
		CustomerDao dao = new CustomerDbUtil(factory);
		
        
		//bind to list
		customers = dao.getCustomers();

		
		
		//Get Http-Session
		HttpSession session = request.getSession(true);
		// add students to the request
		request.setAttribute("CUSTOMER_LIST", customers);
				
		
		//Dispatch Request
		page = "/list-students.jsp";
		requestDispatched(request, response, page);
		
		
	}



	


//Get View Customer by ID----------------------------------------------------------------------------------------------

			private void singleCustomer(HttpServletRequest request,
			HttpServletResponse response) throws SQLException, ServletException, IOException 
			{
		      	
				//get customer code
		         String theCustomerCode = request.getParameter("CustomerCode");

				//create list/pojo obj
		        Customer thecustomer = null;

				//get H-Session
				CustomerDao dao = new CustomerDbUtil(factory);
				
		        //bind to list
				thecustomer = dao.getCustomerById(theCustomerCode);

				
				 //Get Http-Session
				HttpSession session = request.getSession(true);
				// add students to the request
				request.setAttribute("SINGLE_CUSTOMER", customer);
				

				listCustomer(request,response);
			}







//ADD Customer --------------------------------------------------------------------------------------------

private void addCustomer(HttpServletRequest request,
			HttpServletResponse response) throws SQLException 
		{
				//Read Data off the form
		    	String customerCode = request.getParameter("CustomerCode");
		    	String customerName = request.getParameter("CustomerName");
		    	String customerAddress1 = request.getParameter("CustomerAddress1");
		    	String customerAddress2 = request.getParameter("CustomerAddress2");
		    	String customerPincode = request.getParameter("CustomerPincode");
		    	String customerEmail = request.getParameter("CustomerEmail");
		    	String customerContactNumber = request.getParameter("CustomerContactPerson");
		    	String customerPrimaryContactPerson = request.getParameter("CustomerPrimaryContactPerson");
		    	String customerRecordStatus = request.getParameter("CustomerRecordStatus");
		    	String customerFlag = request.getParameter("CustomerFlag");
		    	
		    	String createdDate = new java.util.Date().toString();
		    	String createdBy = request.getParameter("UserName");
		    	String modifiedDate = "-";
		    	String modifiedBy = "-";
		    	String authorizedDate = "-";
		    	String authorizedBy = "-";
		    	
		    	
		    	
				// create a new Customer object
		    	Customer theCustomer = new Customer(customerCode, customerName, customerAddress1,
						 customerAddress2, customerPincode, customerEmail, customerContactNumber,
						 customerPrimaryContactPerson, customerRecordStatus, customerFlag, createdDate,
						 createdBy, modifiedDate, modifiedBy, authorizedDate, authorizedBy);
		   			
		    	
		    	//Get Hibernate Session
		    	CustomerDao dao = new CustomerDbUtil(factory);


				// add the student to the database
				dao.addCustomer(theCustomer);
				
				
				 //Get Http-Session
				HttpSession session = request.getSession(true);
				request.setAttribute("ADDED_CUSTOMER", thecustomer);		
				
	
				listCustomer(request, response);	
		
		
		}





//Delete-----------------------------------------------------------------------
	private void deleteCustomer(HttpServletRequest request,
			HttpServletResponse response) throws SQLException 
	{

			//get parameter
			String theCustomerCode = request.getParameter("CustomerCode");
			
			Customer customer= null; 
			
	        //Get H-Session 
			CustomerDao dao = new CustomerDbUtil(factory);
							  

			//Call DB
			//customerDbUtil.deleteCustomer(theCustomerCode);
			

			//Bind Customer Code
			
			customer.setCustomerCode(theCustomerCode);
			dao.deleteCustomer(theCustomerCode);
			
			//Display List
			listCustomer(request, response);
	}










//Load Customer By ID into Form..........................................................................................

	private void loadCustomer(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException, NumberFormatException, SQLException 
	
	   {
			//get customer code
	         String theCustomerCode = request.getParameter("customercode");

			//Get Http-Session
			HttpSession session = request.getSession(true);
							
			//create list/pojo obj
	        Customer thecustomer = null;

			//get H-Session
			CustomerDao dao = new CustomerDbUtil(factory);
			
	        

	        //bind to list
			thecustomer = dao.getCustomerById(theCustomerCode);

	    
					
			//get customer
			//Customer theCustomer = CustomerDbUtil.loadCustomer(customerID);
					
			//to request object
			request.setAttribute("THE_CUSTOMER",theCustomer);
					
					
			//dispatched
			/*RequestDispatcher requestDispatcher = request.getRequestDispatcher("/update-form.jsp");
			requestDispatcher.forward(request,response);
			*/
			page = "/update-form.jsp";
			requestDispatched(request, response, page);
			
			
	}





//Update Customer By ID--------------------------------------------------------------

private void updateCustomer(HttpServletRequest request,
			HttpServletResponse response) throws SQLException 
	{
		

		//Read Data off the form
    	String customerCode = request.getParameter("CustomerCode");
    	String customerName = request.getParameter("CustomerName");
    	String customerAddress1 = request.getParameter("CustomerAddress1");
    	String customerAddress2 = request.getParameter("CustomerAddress2");
    	String customerPincode = request.getParameter("CustomerPincode");
    	String customerEmail = request.getParameter("CustomerEmail");
    	String customerContactNumber = request.getParameter("CustomerContactPerson");
    	String customerPrimaryContactPerson = request.getParameter("CustomerPrimaryContactPerson");
    	String customerRecordStatus = request.getParameter("CustomerRecordStatus");
    	String customerFlag = request.getParameter("CustomerFlag");
    	
    	
    	String modifiedDate = new java.util.Date().toString();
    	String modifiedBy = request.getParameter("CustomerName");
    	String authorizedDate = "-";
    	String authorizedBy = "-";	
		
		
    	

    	//Object
        	Customer theCustomer = new Customer(customerCode, customerName, customerAddress1,
    				 customerAddress2, customerPincode, customerEmail, customerContactNumber,
    				 customerPrimaryContactPerson, customerRecordStatus, customerFlag, 
    				  modifiedDate, modifiedBy, authorizedDate, authorizedBy);
        
        	
        	CustomerDao dao = new CustomerDbUtil(factory);
			customer = dao.updateCustomer(thecustomer);
					
					if(customer!=null)
						{
		                    page = "/WEB-INF/jsp/viewcustomer.jsp";
							requestDispatched(request, response, page);
						}

						else
						{
							requestDispatched(request, response, page);
					}
        	
        	
        	
        	//display list 
        	listCustomer(request,response);
    	
		
	}


