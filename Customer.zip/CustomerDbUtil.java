package com.nucleus.nsbt.batch5.brd2.modellayer;





import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;


public class CustomerDbUtil implements CustomerDao
{
	
	private SessionFactory factory = null;
	private Transaction tx = null;
	Customer customer = new Customer();

		
	

	//Check Back Method
	//Customer DAO??
	public CustomerDbUtil(SessionFactory factory) 
		{
			this.factory = factory;
		}




		
//Multi view-------------------------------------------------------------------------------------
		public List<Customer> getCustomers() 
		{
			List<Customer> list = null;
			
			Session session = factory.openSession();
		    tx = session.getTransaction();
		
			try 
			{
				tx.begin();
				Query query = session.createQuery("from <table>");
				list = query.list();
				tx.commit();
			} 


			catch (HibernateException e) 
			{
				e.printStackTrace();
			} 

			
			finally 
			{
				if (session != null)
					session.close();

			}
			return list;
		}





//Identified by Unique - Code-----------------------------------------------------------------------------------------------
		public Customer getCustomerByID(String theCustomerCode) 
		{
			Session session = factory.openSession();
			tx = session.getTransaction();
			
           try
           {
           	tx.begin();
			Query query = session.createQuery("select c from <Table> c  where c.customerCode=:theCustomerCode");
			query.setParameter("CustomerCode", theCustomerCode);
		
			List<Customer> thecustomer = query.list();

			if (thecustomer.size() > 0) 
			{
				customer = thecustomer.get(0);
				tx.commit();
				return customer;
			} 
			else 
				return null;
            }


			catch (HibernateException e) 
			{
				tx.rollback();
				e.printStackTrace();
			} 

			finally 
			{
				if (session != null)
					session.close();

			}
			return customer;
		}






//Add Customer---------------------------------------------------------------------------------------------------
		public Customer addCustomer(Customer customer) 
		{
			Session session = factory.openSession();
			tx = session.getTransaction();

			try 
			{
				tx.begin();
				session.save(customer);
				tx.commit();
			} 


			catch (HibernateException e) 
			{
				tx.rollback();
				e.printStackTrace();
			} 

			finally 
			{
				if (session != null)
					session.close();
			}
			
			return customer;

		}






//Update-------------------------------------------------------------------------------------------------
		public Customer updateCustomer(Customer customer) 
		{
			//boolean isAdded=false;
			Session session = factory.openSession();
			tx = session.getTransaction();
			try {
			
				tx.begin();

				Query query = session
						.createQuery("update Customer set customer_name=:customerName, customer_address1=:customerAddress1,customer_address2=:customerAddress2,customer_pinCode=:customerPincode,customer_email=:customerEmail,customer_contact_number=:customerContactNumber,customer_primary_contact_person=:customerPrimaryContactPerson, customer_record_status=:customerRecordStatus,customer_flag_status=:customerFlag where customerCode=:customerCode");


	         query.setString("CustomerCode", customer.getCustomerCode());
	         query.setString("CustomerName",customer.getCustomerName());
	         query.setString("CustomerAddress1",customer.getCustomerAddress1());
	         query.setString("CustomerAddress2",customer.getCustomerAddress2());
	         query.setString("CustomerPincode",customer.getCustomerPinCode());
	         query.setString("CustomerEmail",customer.getCustomerEmail());
	         query.setString("CustomerContactNumber",customer.getCustomerContactNumber());
	         query.setString("CustomerPrimaryContactPerson",customer.getCustomerPrimaryContactPerson());
	         query.setString("customerRecordStatus",customer.getCustomerRecordStatus());
	         query.setString("CustomerFlag",customer.getCustomerFlagStatus());
	          
	         query.executeUpdate();
	         tx.commit();
	          
	   
			}

			 catch (HibernateException e) 
			 {
				tx.rollback();
				e.printStackTrace();
			} 

			finally 
			{
				if (session != null) 
				{
					session.close();
				}
			}
			
			return customer;
		}

		



		
//Delete---------------------------------------------------------------------------------------------------
		public Customer deleteCustomer(String thecustomercode) 
		{

			Session session = factory.openSession();
			tx = null; 
					
			tx = session.getTransaction();
			try
			{
				tx.begin();
			
				Query query = session
						.createQuery("select * from Customer c  where c.customer_code=:thecustomercode");
				query.setString("theCustomerCode", thecustomercode);
				
				List<Customer> thecustomer = query.list();
			
				if (thecustomer.size() > 0) 
				{
					customer = thecustomer.get(0);
					session.delete(customer);
					tx.commit();
				}

			}

			 catch (HibernateException e) 
			 {
				tx.rollback();
				e.printStackTrace();
			} 

			finally 
			{
				if (session != null) 
				{
					session.close();
				}
			}
			
			return customer;
		}

		







		
	}

