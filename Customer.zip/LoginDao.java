package com.nu.dao;

import java.util.List;

import com.nu.model.UserLogin;

public interface LoginDao 
{

	public List<UserLogin> validate(String username, String password);
}
