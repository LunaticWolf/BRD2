package com.nu.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.nu.model.UserLogin;

public class LoginDbUtil implements LoginDao
{
	List<UserLogin> list = null;
	private Session session = null;
	Transaction tx =null; 

	public LoginDBUtil(SessionFactory factory) 
	{
		session = factory.openSession();
	}


	public List<UserLogin> validate(String username, String password)
	{
	 
		tx = session.getTransaction();
	 try
	 {
		tx.begin();
	 
	 Query query = session.createQuery("select u from User u where "
	 		+ "u.user_name=: username and u.password=:password ");
	 
	 list = query.list();
	 
	 if(!list.isEmpty())
	 {
		 list = (List<UserLogin>) list.get(0);
		  tx.commit();
		 
	 }
	 
	 else
	 {
		 return null;
	 }
	 
	}
	 
	 catch (HibernateException e) 
		{
			tx.rollback();
			e.printStackTrace();
		} 

		finally 
		{
			if (session != null)
				session.close();

		}
	 
	return list;
	 
		
	}

}
