package com.nucleus.servlet.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

public class CustomerDbUtil
{

		private static DataSource dataSource;

		public CustomerDbUtil(DataSource theDataSource) 
		{
			dataSource = theDataSource;
		}

	
		//Multiple View
	
		public List<Customer> getCustomer() throws SQLException 
		{
		
			//create List Object
			List<Customer> customers = new ArrayList<>();
		
		
			//Initialize connection essentials
			Connection myConn = null;
			Statement myStmt = null;
			ResultSet myRs = null;
		
		
			try
			{
				//get connection 
				myConn = dataSource.getConnection();
			
				//create query
				String sql = "select * from tablechair order by customer_id";
			
			
				//create statement
				myStmt = myConn.createStatement();
			
			
				//execute query
				myRs = myStmt.executeQuery(sql);
		
		
				//process result set
				while(myRs.next())
				  {
					int customerId = myRs.getInt("customer_id");
				
					String customerCode = myRs.getString("customer_code");
					String customerName = myRs.getString("customer_name");
					String customerAddress1 = myRs.getString("customer_address1");
					String customerAddress2 = myRs.getString("customer_address2");
					String customerPincode = myRs.getString("customer_pincode");
					String customerEmail = myRs.getString("customer_email");
					String customerContactNumber = myRs.getString("customer_contact_number");
					String customerPrimaryContactPerson = myRs.getString("customer_primary_contact_person");
					String customerRecordStatus = myRs.getString("customer_record_status");
					String customerFlag = myRs.getString("customer_flag_status");
					
					String createdDate = myRs.getString("created_date");
					String createdBy = myRs.getString("created_by");
					String modifiedDate = myRs.getString("modified_date");
					String modifiedBy = myRs.getString("modified_by");
					String authorizedDate = myRs.getString("authorized_date");
					String authorizedBy = myRs.getString("authorized_by");
				
				
					// create new Customer object
					Customer tempCustomer = new Customer(customerId, customerCode, customerName, customerAddress1,
						 customerAddress2, customerPincode, customerEmail, customerContactNumber,
						 customerPrimaryContactPerson, customerRecordStatus, customerFlag, createdDate,
						 createdBy, modifiedDate, modifiedBy, authorizedDate, authorizedBy);
				
					// Customer fields added to the list-customers
					customers.add(tempCustomer);		
				
				  
				  }
			
				return customers;
				
			}
		
			catch(SQLException e)
			{
				System.out.println("SQL Exception Encountered While Displaying Data..- getCustomer()");
				e.printStackTrace();
		
		     }
			
			finally
			{
				close(myConn, myStmt, myRs);
				//myConn will still be avaliable for others to Connect
			}
			return customers;
		
		
		
	}

	
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	private static void close(Connection myConn, Statement myStmt, ResultSet myRs) throws SQLException 
	{
	  if(myConn!=null)
		  myConn.close();
	  
		
	  if(myStmt!=null)
		  myStmt.close();
	  
	  
	  if(myRs!=null)
		  myRs.close();
	}

	
	
	
	
	
	

	public void addCustomer(Customer theCustomer) throws SQLException 
	{
	//Initialize Db Essentials
		Connection myConn = null;
		PreparedStatement myStmt = null;
		
		
		try 
		{
			//get connection 
			myConn = dataSource.getConnection();
			
			
			//Query
			String sql = "insert into tablechair" + "(customerCode, customerName, customerAddress1,\r\n" + 
					"				 customerAddress2, customerPincode, customerEmail, customerContactNumber,\r\n" + 
					"				 customerPrimaryContactPerson, customerRecordStatus, customerFlag,  createdDate,\r\n" + 
					"				 createdBy, modifiedDate, modifiedBy, authorizedDate, authorizedBy)" +
					"values(?, ?, ? , ?, ?, ?, ?, ?, ?, ?, ?, ? , ?, ?, ?, ?)";
			
			
			//Prepare Statement
			myStmt = myConn.prepareStatement(sql);
			
			
			
			//set param values -> add to database
			
			myStmt.setString(1, theCustomer.getCustomerCode());
			myStmt.setString(2, theCustomer.getCustomerName());
			myStmt.setString(3, theCustomer.getCustomerAddress1());
			myStmt.setString(4, theCustomer.getCustomerAddress2());
			myStmt.setString(5, theCustomer.getCustomerPincode());
			myStmt.setString(6, theCustomer.getCustomerEmail());
			myStmt.setString(7, theCustomer.getCustomerContactNumber());
			myStmt.setString(8, theCustomer.getCustomerPrimaryContactPerson());
			myStmt.setString(9, theCustomer.getCustomerRecordStatus());
			myStmt.setString(10, theCustomer.getCustomerFlag());
			
			
			myStmt.setString(11, theCustomer.getCreatedDate());
			myStmt.setString(12, theCustomer.getCreatedBy());
			myStmt.setString(13, theCustomer.getModifiedDate());
			myStmt.setString(14, theCustomer.getModifiedBy());
			myStmt.setString(15, theCustomer.getAuthorizedDate());
			myStmt.setString(16, theCustomer.getAuthorizedBy());
			
			
			myStmt.execute();
		}
		catch(SQLException e)
		{
			System.out.println("Couldn't Add..");
			e.printStackTrace();
		}
		finally
		{
			close(myConn,myStmt, null);
		}	
		
	}


	public void deleteCustomer(String theCustomerId) throws SQLException 
	{
        //initialize db essentials
 	  	Connection myConn = null;
		PreparedStatement myStmt = null;
		
		
		try
		{
			//get connection
			myConn = dataSource.getConnection();
			
			//get ID
			int customerId = Integer.parseInt(theCustomerId);

			//Query
			String sql = "delete from Tablechair where customer_id = ?";
			
			//Prepare Statement
			myStmt = myConn.prepareStatement(sql);
			
			
			//identify id record
			myStmt.setInt(1, customerId);
			
			//execute
			myStmt.execute();
		}
		
		catch(SQLException e)
		{
			System.out.println("Couldn't delete record");
			e.printStackTrace();
		}
		
		finally
		{
			close(myConn, myStmt, null);
		}
		
		
	}


	public static Customer loadCustomer(String customerID) throws SQLException, NumberFormatException 
	{
        Customer theCustomer=null;
		
		Connection myConn = null;
		PreparedStatement myStmt = null;
		ResultSet myRs = null;
		
		try
		{
			//retrieve ID
			int theCustomerId = Integer.parseInt(customerID);
			
			
			//get Connection 
			myConn = dataSource.getConnection();
			
			
			//Query 
			String sql = "Select * from Tablechair where id = ?";
			
			
			//Prepare statement
			myStmt=myConn.prepareStatement(sql);
			
			
			//set Id
			myStmt.setInt(1, theCustomerId);
		
			
			//Result Set
			myRs = myStmt.executeQuery();
			
			
			//Process result Set
			if(myRs.next())
			{
				String customerCode = myRs.getString("customer_code");
				String customerName = myRs.getString("customer_name");
				String customerAddress1 = myRs.getString("customer_address1");
				String customerAddress2 = myRs.getString("customer_address2");
				String customerPincode = myRs.getString("customer_pincode");
				String customerEmail = myRs.getString("customer_email");
				String customerContactNumber = myRs.getString("customer_contact_number");
				String customerPrimaryContactPerson = myRs.getString("customer_primary_contact_person");
				String customerRecordStatus = myRs.getString("customer_record_status");
				String customerFlag = myRs.getString("customer_flag_status");
				
				
				theCustomer = new Customer(theCustomerId, customerCode, customerName, customerAddress1, customerAddress2, customerPincode,customerEmail, 
						customerContactNumber,customerPrimaryContactPerson,customerRecordStatus, customerFlag );
			}
			
			return theCustomer;
		}
		catch(SQLException e)
		{
			System.out.println("Could't losd page for update");
			e.printStackTrace();
		}
		finally
		{
			close(myConn, myStmt, null);
		}
		
		
		
		return theCustomer;
		
	}


	public void updateCustomer(Customer theCustomer) throws SQLException
	{
		Connection myConn = null;
		PreparedStatement myStmt = null;

		try {
			// get db connection
			myConn = dataSource.getConnection();
			
			String sql= "update table tablechair " + "set customerCode =?, customerName=?, customerAddress1=?,\r\n" + 
					"				 customerAddress2=?, customerPincode=?, customerEmail=?, customerContactNumber=?,\r\n" + 
					"				 customerPrimaryContactPerson=?, customerRecordStatus=?, customerFlag=?,  createdDate=?,\r\n" + 
					"				 createdBy=?, modifiedDate=?, modifiedBy=?, authorizedDate=?, authorizedBy=? where id =?";
			
			//Statement
			myStmt =  myConn.prepareStatement(sql);
			
			
			//set Param values --added to database
			myStmt.setString(1, theCustomer.getCustomerCode());
			myStmt.setString(2, theCustomer.getCustomerName());
			myStmt.setString(3, theCustomer.getCustomerAddress1());
			myStmt.setString(4, theCustomer.getCustomerAddress2());
			myStmt.setString(5, theCustomer.getCustomerPincode());
			myStmt.setString(6, theCustomer.getCustomerEmail());
			myStmt.setString(7, theCustomer.getCustomerContactNumber());
			myStmt.setString(8, theCustomer.getCustomerPrimaryContactPerson());
			myStmt.setString(9, theCustomer.getCustomerRecordStatus());
			myStmt.setString(10, theCustomer.getCustomerFlag());
			
			
			myStmt.setString(11, theCustomer.getCreatedDate());
			myStmt.setString(12, theCustomer.getCreatedBy());
			myStmt.setString(13, theCustomer.getModifiedDate());
			myStmt.setString(14, theCustomer.getModifiedBy());
			myStmt.setString(15, theCustomer.getAuthorizedDate());
			myStmt.setString(16, theCustomer.getAuthorizedBy());
			myStmt.setInt(17, theCustomer.getCustomerId());
			
			myStmt.execute();
		}
		
			finally 
			{
				// clean up JDBC objects
				close(myConn, myStmt, null);
			}
			myStmt.execute();
		
		
	
		
	}
	
	
	
	
	
	
	
	
}


	
