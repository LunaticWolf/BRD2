package com.nucleus.servlet.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.nucleus.servlet.model.Customer;
import com.nucleus.servlet.model.CustomerDbUtil;


@WebServlet("/CustomerControllerServlet")
public class CustomerControllerServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
	private CustomerDbUtil customerDbUtil;

	@Resource(name="jdbc/ServletCrud")
	private DataSource dataSource;
	

	
	public void init() throws ServletException 
	{
		super.init();
		
		// create Customer db util ... and pass in the conn pool / datasource
		try 
		{
			customerDbUtil = new CustomerDbUtil(dataSource);
		}
		catch (Exception exc) 
		{
			throw new ServletException(exc);
		}
	}
	
	
	
	
	
	
	
 
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{

		
	}


	
	
	
	
	
	
	
	
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
	
		try
		{
			//read Command from  page
			String theCommand = request.getParameter("Command");
			
			
			if(theCommand == null)
			{
				theCommand = "LISTVIEW";
			}
			
			
			//Re-route servlet
			switch(theCommand)
			{
			case "LIST": listCustomer(request,response);
			break;
			
			case "ADD": addCustomer(request,response);
			break;
			
			case "LOAD": loadCustomer(request, response);
			break;
				
			case "UPDATE": updateCustomer(request, response);
			break;
			
			case "DELETE": deleteCustomer(request, response);
			break;
				
			default: listCustomer(request, response);
			}
			
		}
			
			catch(Exception e)
			{
				throw new ServletException();
			}
		}
		
	



	
	
	//-----------------------------------------------------------------


	private void listCustomer(HttpServletRequest request,
			HttpServletResponse response) throws SQLException, ServletException, IOException 
	{
		//create list
        List<Customer> customers = customerDbUtil.getCustomer();
		
		// add students to the request
		request.setAttribute("CUSTOMER_LIST", customers);
				
		// send to JSP
		RequestDispatcher dispatcher = request.getRequestDispatcher("/list-students.jsp");
		dispatcher.forward(request, response);
		
		
	}
	
	
	
//-------------------------------------------------------------------------------------------------
	private void addCustomer(HttpServletRequest request,
			HttpServletResponse response) throws SQLException 
	{
		//Read Data off the form
    	String customerCode = request.getParameter("CustomerCode");
    	String customerName = request.getParameter("CustomerName");
    	String customerAddress1 = request.getParameter("CustomerAddress1");
    	String customerAddress2 = request.getParameter("CustomerAddress2");
    	String customerPincode = request.getParameter("CustomerPincode");
    	String customerEmail = request.getParameter("CustomerEmail");
    	String customerContactNumber = request.getParameter("CustomerContactPerson");
    	String customerPrimaryContactPerson = request.getParameter("CustomerPrimaryContactPerson");
    	String customerRecordStatus = request.getParameter("CustomerRecordStatus");
    	String customerFlag = request.getParameter("CustomerFlag");
    	
    	String createdDate = new java.util.Date().toString();
    	String createdBy = request.getParameter("CustomerName");
    	String modifiedDate = "-";
    	String modifiedBy = "-";
    	String authorizedDate = "-";
    	String authorizedBy = "-";
    	
    	
    	
		// create a new Customer object
    	Customer theCustomer = new Customer(customerCode, customerName, customerAddress1,
				 customerAddress2, customerPincode, customerEmail, customerContactNumber,
				 customerPrimaryContactPerson, customerRecordStatus, customerFlag, createdDate,
				 createdBy, modifiedDate, modifiedBy, authorizedDate, authorizedBy);
   			
    	
		// add the student to the database
		customerDbUtil.addCustomer(theCustomer);
						
		// send back to main
		//listCustomer(request, response);	
		
		
	}

	
//-------------------------------------------------------------------------
	private void deleteCustomer(HttpServletRequest request,
			HttpServletResponse response) throws SQLException 
	{

		//get parameter
		String theCustomerId = request.getParameter("CustomerId");
		
		
		//Call DB
		customerDbUtil.deleteCustomer(theCustomerId);
		   
		
		//Display List
		//listCustomer(request, response);
	}

	
	
	//-------------------------------------------------------------------------
	private void loadCustomer(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException, NumberFormatException, SQLException 
	{
		
		//get id
		String customerID = request.getParameter("CustomerID");
				
				
		//get customer
		Customer theCustomer = CustomerDbUtil.loadCustomer(customerID);
				
		//to request object
		request.setAttribute("THE_CUSTOMER",theCustomer);
				
				
		//dispatched
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("/update-form.jsp");
		requestDispatcher.forward(request,response);
		
		
		
	}

	
	
//-------------------------------------------------------------------------	
	
	private void updateCustomer(HttpServletRequest request,
			HttpServletResponse response) throws SQLException 
	{
		

		//Read Data off the form
    	String customerCode = request.getParameter("CustomerCode");
    	String customerName = request.getParameter("CustomerName");
    	String customerAddress1 = request.getParameter("CustomerAddress1");
    	String customerAddress2 = request.getParameter("CustomerAddress2");
    	String customerPincode = request.getParameter("CustomerPincode");
    	String customerEmail = request.getParameter("CustomerEmail");
    	String customerContactNumber = request.getParameter("CustomerContactPerson");
    	String customerPrimaryContactPerson = request.getParameter("CustomerPrimaryContactPerson");
    	String customerRecordStatus = request.getParameter("CustomerRecordStatus");
    	String customerFlag = request.getParameter("CustomerFlag");
    	
    	
    	String modifiedDate = new java.util.Date().toString();
    	String modifiedBy = request.getParameter("CustomerName");
    	String authorizedDate = "-";
    	String authorizedBy = "-";	
		
		
    	

    	//Object
        	Customer theCustomer = new Customer(customerCode, customerName, customerAddress1,
    				 customerAddress2, customerPincode, customerEmail, customerContactNumber,
    				 customerPrimaryContactPerson, customerRecordStatus, customerFlag, 
    				  modifiedDate, modifiedBy, authorizedDate, authorizedBy);
        
        	
        	
        	
        	customerDbUtil.updateCustomer(theCustomer);
        	
        	//display list 
        	//listCustomer(request,response);
    	
		
	}


	
	

}
