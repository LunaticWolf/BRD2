/**
 * 
 */
/**
 * @author Devil
 *
 */
package com.nu.login.model;