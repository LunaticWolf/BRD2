package com.nu.login.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name="Logger_18060163")
public class Logger 
{
	@Column(name="user_id")
	private int id;
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private String userId;
	
	@Column(name="user_name")
	private String username;
	@Column(name="user_password")
	private String password;
	
	@Column(name="user_role")
	private String profile;
	
	
	
	
	
	//Getters----------------------------------------------------------------------------
	
	
	public String getUserId() 
	{
		return userId;
	}
	
	public int getId() 
	{
		return id;
	}
	public String getUsername() 
	{
		return username;
	}
	public String getPassword() 
	{
		return password;
	}
	
	public String getProfile() {
		return profile;
	}
	
	
	
	
	//Setters----------------------------------------------------------------------------

	public void setId(int id) {
		this.id = id;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setProfile(String profile) {
		this.profile = profile;
	}
	
	
	
	
	
	//With User and Password---------------------------------------------------------------------------------
	public Logger(String userId, String password) {
		super();
		this.userId = userId;
		this.password = password;
	}
	
	
	
	

	//With Id......................
	public Logger(int id, String userId, String username, String password, String profile) {
		super();
		this.id = id;
		this.userId = userId;
		this.username = username;
		this.password = password;
		this.profile = profile;
	}
	
	
//Without Id...............	
	public Logger(String userId, String username, String password, String profile) {
		super();
		this.userId = userId;
		this.username = username;
		this.password = password;
		this.profile = profile;
	}

	@Override
	public String toString() {
		return "Logger [id=" + id + ", username=" + username + ", password=" + password + "]";
	}
	
	
	
	

}
