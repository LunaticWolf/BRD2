package com.nu.login.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="LoggerProfile_18060163")
public class LoggerProfile 
{
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	@Column(name="user_id")
	private int id;
	
	
	@Column(name="user_role")
	private String profile;
	@Column(name="user_profile_description")
	private String description;

	
	
}
