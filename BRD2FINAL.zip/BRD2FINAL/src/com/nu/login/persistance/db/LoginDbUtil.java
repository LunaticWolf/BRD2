package com.nu.login.persistance.db;
import com.nu.login.model.Logger;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.HibernateException;
import org.hibernate.Session;

public class LoginDbUtil implements LoginDao
{
    
	
	private SessionFactory factory=null;
	private Session session = null;
	
	
	public LoginDbUtil(SessionFactory factory) 
	{
		this.factory=factory;
	}



	@Override
	public Logger validate(String userId, String passWord) 
	{	
		session = factory.openSession();
		Transaction transaction = session.getTransaction();
		
		Logger user = null;
		
		try 
		{
			transaction.begin();
			
			user = (Logger) session.get(Logger.class, userId);
			String user1 = user.getUserId();
			String pass1 = user.getPassword();
			
			
			if((user1 == userId) && (pass1 == passWord))
			{
			  return user;
			}
			
			
			transaction.commit();
		}
		
		finally
		{
			sessionClose();
		}
		return user;
	
	}



	
	
	
	@Override
	 public Logger register(Logger logg)
	 {
		Transaction transaction = session.getTransaction();	
		try 
		{
			transaction.begin();
			
			session.save(logg);
			
			transaction.commit();
			
	     }
		catch (HibernateException e) 
		{
			transaction.rollback();
			e.printStackTrace();
		} 
		
		finally
		{
			sessionClose();
		}
		return logg;
	 }


		private void sessionClose() 
		{
			if(session!=null)
			session.close();
		}
		
}
