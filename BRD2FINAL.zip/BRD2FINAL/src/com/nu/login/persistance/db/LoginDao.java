package com.nu.login.persistance.db;

import com.nu.login.model.Logger;

public interface LoginDao
{
 public Logger validate(String userId, String passWord);


public Logger register(Logger logg);
}
