package com.nu.login.persistance.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.SessionFactory;

import com.nu.login.persistance.db.LoginDao;
import com.nu.login.persistance.db.LoginDbUtil;
import com.nu.login.model.Logger;



@WebServlet("/LoginControllerServlet")
public class LoginControllerServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
	 private SessionFactory factory=null;
	 private HttpSession httpSession=null;
	
	
	 
	@Override
	public void init(ServletConfig config) throws ServletException 
	{
		super.init(config);
		factory = (SessionFactory) this.getServletContext().getAttribute("FACTORY");

	}
	
	
	
 
	public LoginControllerServlet() 
    {
        super();
   
    }

  
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
	   
		String page = "/js/login-home.jsp";
		
		if(httpSession!=null)
        {
       	  httpSession.invalidate();
        }
		
		else
		{
			String theCommand = request.getParameter("Command").toUpperCase();
			       switch(theCommand)
				   {
				   case "LOGIN" : page = "/js/login-control.jsp";
				   break;
				   
				   case "REGISTER": page = "/js/register-control.jsp";
				   break;
				   
				   case "HOME": page = "/js/login-home.jsp";
				   break;
				   
				   default: page="/js/login-home.jsp";
				   }
		}
	       pageRequestDispatcher(request, response, page);
	}

	

	
	
	private void pageRequestDispatcher(HttpServletRequest request, HttpServletResponse response, String page)
			throws ServletException, IOException {
		RequestDispatcher requestDispatcher = request.getRequestDispatcher(page);
		 requestDispatcher.forward(request, response);
	}

	
	
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
	     response.setContentType("text/html");
	     
		String theCommand = request.getParameter("Command").toUpperCase();
		String page = "/js/login-home.jsp";	   
	  
	       switch(theCommand)
		   {
		   case "LOGIN" : loginUser(request,response);
		   break;
		   
		   case "REGISTER": registerUser(request,response);
		   break;
		   
		   case "HOME": page = "/js/login-home.jsp";
		   break;
		   
		   default: page="/js/login-home.jsp";
		   }
	       
	       pageRequestDispatcher(request, response, page);
		
		
		
	}


	private void registerUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String userId = request.getParameter("UserId");
		String userName = request.getParameter("UserName");
		String userPassword = request.getParameter("Password");
		String profile = request.getParameter("Role");
		
		
		Logger logg = new Logger(userId,userName, userPassword,profile);
		
		LoginDao dao = new LoginDbUtil(factory);
		
		Logger registeredUser = dao.register(logg);
		
		httpSession = request.getSession();
		
		httpSession.setAttribute("REGISTER_LOGIN", registeredUser);
		
		String page = "/js/login-home.jsp";
		pageRequestDispatcher(request, response, page);
		
	}



	private void loginUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		String page = "/js/login-home.jsp";
		
		String userId = request.getParameter("UserId");
		String passWord = request.getParameter("Password");
		
		LoginDao dao = new LoginDbUtil(factory);
		
		Logger Logg = dao.validate(userId,passWord);
	    
		if(Logg!=null)
		 {
			httpSession.setAttribute("LOGIN_USER", Logg);
			page =" /js/Home.jsp";
		 }
		else
		{
			page = "/js/login-home.jsp";
		}
		
		pageRequestDispatcher(request, response, page);
		
	}

}
