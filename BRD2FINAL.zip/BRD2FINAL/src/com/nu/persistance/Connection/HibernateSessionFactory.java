package com.nu.persistance.Connection;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

@SuppressWarnings("deprecation")
public class HibernateSessionFactory 
{
	private static SessionFactory factory = null;

	
	private HibernateSessionFactory() 
	{}


	public static SessionFactory getSessionFactory() 
	{

	try 
		{
			factory = new AnnotationConfiguration().configure().buildSessionFactory();
				
			return factory;
		}
	
	catch(HibernateException e)
	{
			e.printStackTrace();
	}
	
	
		return factory;
	}


}
