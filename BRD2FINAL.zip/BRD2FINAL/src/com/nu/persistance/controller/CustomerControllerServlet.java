package com.nu.persistance.controller;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;




import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;


import org.hibernate.SessionFactory;

import com.nu.persistance.db.CustomerDao;
import com.nu.persistance.db.CustomerDbUtil;
import com.nu.persistance.model.Customer;



@WebServlet("/CustomerControllerServlet")
public class CustomerControllerServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
	private SessionFactory factory = null;
	private HttpSession httpSession=null;

	
	//Init() override - get hibernate factory
	@Override
	public void init(ServletConfig config) throws ServletException 
	{
		super.init(config);
		factory = (SessionFactory) this.getServletContext().getAttribute("FACTORY");
		
	}
	
	
	
	
  

//Default
	
    public CustomerControllerServlet()
    {
        super();

    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String theCommand = request.getParameter("Command").toUpperCase();
		String page = "/js/Home.jsp";
	
		Cookie theCookie = null;
		loginCookie(request);
		
		//RESPONSE CONTROLLER
		//Commands Through Nav Bar
		switch(theCommand)
		{
		    
		    case"HOME":page="/js/Home.jsp"; 
		
			//ADD
			case"ADD": page="/js/add-customer.jsp";
			break;
			

			//VIEW			
			case"SINGLEVIEW": page = "/js/search-id.jsp"; //Ask C-Code------------------------
			break;
			
			case"MULTIVIEW": listCustomer(request,response);
			break;
			
			
			//UPDATE
			case"UPDATE": page="/js/search-id.jsp";//Ask C-Code---------------------------
			break;
			
			
			//DELETE
			case"DELETE": page="/js/search-id.jsp";//Ask C-Code-------------------------------------
			break;
			
			
			//Add LogOUT
			case"LOGOUT": if(httpSession!=null)
				            httpSession.invalidate();
			    
								if(theCookie!=null)
			                	 theCookie.setMaxAge(0);
				
							page = "login-home.jsp";
			break;
			
			default: page="/js/Home.jsp";
			
			
			
		}
		
		pageRequestDispatcher(request, response, page);
		

	}






	//Dispatch Page request to browser...................................................................................
	private void pageRequestDispatcher(HttpServletRequest request, HttpServletResponse response, String page)
			throws ServletException, IOException 
	{
		RequestDispatcher requestDispatcher = request.getRequestDispatcher(page);
		requestDispatcher.forward(request, response);
	}

	
	
	
	
	
	
	//Confidential Calls
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
	
		
		loginCookie(request);
		
		String theCommand=request.getParameter("Command").toUpperCase();
		//String page="/js/Home.jsp";
		
		//CRUD CONTROLLER
		switch(theCommand)
		{
		    //ADD
			case"ADD": addCustomer(request,response);
			break;
			
			//View
			case"SINGLEVIEW": getId(request,response);
			break;
			
			case"MULTIVIEW": listCustomer(request,response);
			break;
			
			
			
			//get Id and pre-fill form
			case"UPDATE-ID": getId(request, response);
			break;
			
			//Update record
			case"UPDATE": updateCustomer(request,response);
			break;
			
			
			//DELETE
			case"DELETE": getId(request, response);
			break;
			
			
			default: //page = "/js/Home.jsp";
		}
		
//		pageRequestDispatcher(request, response, page);
		

	}






	private void loginCookie(HttpServletRequest request) {
		Cookie theCookie = new Cookie("LOGGEDUSER", request.getParameter("UserName"));
		theCookie.setMaxAge(60*60);
	}

	
	

	





//View All---------------------------------------------------------------------------------------------------------------

	private void listCustomer(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
	   //Get Http Session
		
		httpSession = request.getSession();
				//httpSession.getMaxInactiveInterval(60);---------------------?????????????????????
		
			//Set defaults----------------------------------------------
			//View Page and List Obj
			String page = "/js/view-all.jsp";
			
			//List Object.......
			List<Customer> customers = null;
			
			
			//Get H-Session
			CustomerDao dao = new CustomerDbUtil(factory);
			
			//Get all customers
			customers = dao.getCustomers();
			
			//set attribute to redirect data to jsp
			request.setAttribute("CUSTOMERS_LIST", customers);
		
		pageRequestDispatcher(request, response, page);
		
	}
	
	
	
	
	
	
	
	
	
	
	

	//ADD ----------------------------------------------------------------------------------------------------------------
	
	private void addCustomer(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{		
	
		//Define field values from form data
		String customerCode = request.getParameter("CustomerCode");
		String customerName = request.getParameter("CustomerName");
		
		String customerAddress1 = request.getParameter("CustomerAddress1");
		String customerAddress2 = request.getParameter("CustomerAddress2");
		
		String customerPinCode = request.getParameter("CustomerPinCode");
		//String customerPinCode = Integer.parseInt(pin);
		
		String customerEmail = request.getParameter("CustomerEmail");
		
		String customerContactNumber = request.getParameter("CustomerContactNumber");
		//String customerContactNumber = Integer.parseInt(number);
		 
		String customerPrimaryContactPerson = request.getParameter("CustomerPrimaryContactPerson");
		
		String customerRecordStatus = request.getParameter("CustomerRecordStatus");
		String customerFlagStatus=request.getParameter("CustomerFlagStatus");
		
		String createdDate = new java.util.Date().toString();
		
		//get parameter User Name From Login
		String createdBy = request.getParameter("UserName");
		
		String modifiedDate = "-";
		String modifiedBy = "-";
		
		String authorizedDate = "-";
		String authorizedBy = "-";

		
		
		
		//wrap data to object
		Customer newCustomer = new Customer(customerCode,customerName,customerAddress1,customerAddress2,customerPinCode,customerEmail,
				customerContactNumber,customerPrimaryContactPerson,customerRecordStatus,customerFlagStatus,createdDate,createdBy,modifiedDate,
				modifiedBy,authorizedDate,authorizedBy);
		
		
		
		
		//get factory
		//Customer dao = new CustomerDbUtil(factory);--------------------------------------------------------------
		CustomerDao dao = new CustomerDbUtil(factory);
		
		//Add it to db....
		Customer theCustomer = dao.addCustomer(newCustomer);
		
		//GetSession --> Jsp
		httpSession = request.getSession();
		
		//To View in Jsp
		//request.setAttribute("ADDED_CUSTOMER",theCustomer);
		httpSession.setAttribute("ADDED_CUSTOMER", theCustomer);
		
		
		//Dispatch......
		String page = "/added_customer.jsp";
		pageRequestDispatcher(request, response, page);
		
	}

	
	
	
	private void getId(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		//get Parameters
		String theCustomerCode = request.getParameter("CustomerCode");
		String command = request.getParameter("CommandType");
		String page;
		
		
		
		//get H-factory---------------------------------------------------------------------????????????????
		//CustomerDao dao = new CustomerDbUtil(factory);
		CustomerDao dao = new CustomerDbUtil(factory);
		
		//get Customer
		Customer theCustomer = dao.getCustomerById(theCustomerCode);
		
		
		//getSession
		httpSession = request.getSession();
				
		//To jsp
		request.setAttribute("THE_CUSTOMER", theCustomer);
		
		
		
		switch(command)
		{
			//simple Display
			case"SINGLE_VIEW":page = "/js/single-view-customer.jsp";
			                  pageRequestDispatcher(request, response, page);
			                  
			break;
			
			//Pre-Populated form
			case"UPDATE": page = "/js/update-customer.jsp";
			              pageRequestDispatcher(request, response, page);
			break;
			
		    //delete	
			case"DELETE": deleteCustomer(request,response,theCustomer);
			break;
			
			default: page = "/js/search-id.jsp.jsp";
		
		}
		
		
	}



	private void deleteCustomer(HttpServletRequest request, HttpServletResponse response, Customer theCustomer) throws ServletException, IOException 
	{
		//get factory
		//Customerdao dao = new CustomerDbUtil();--------------??????????????????????????????
		CustomerDao dao = new CustomerDbUtil(factory);
		
		Customer wasCustomer = dao.deleteCustomer(theCustomer);
		
		request.setAttribute("DELETED_CUSTOMER", wasCustomer);
		
		String page = "Deleted-customer.jsp";
		pageRequestDispatcher(request, response, page);
		
		
	}

	

	
	private void updateCustomer(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		
		//Define field values from form data
		String customerCode = request.getParameter("CustomerCode");
		String customerName = request.getParameter("CustomerName");
		
		String customerAddress1 = request.getParameter("CustomerAddress1");
		String customerAddress2 = request.getParameter("CustomerAddress2");
		
		String customerPinCode = request.getParameter("CustomerPinCode");
		//String customerPinCode = Integer.parseInt(pin);
		
		String customerEmail = request.getParameter("CustomerEmail");
		
		String customerContactNumber = request.getParameter("CustomerContactNumber");
		//String customerContactNumber = Integer.parseInt(number);
		 
		String customerPrimaryContactPerson = request.getParameter("CustomerPrimaryContactPerson");
		
		//Modified - M
		String customerRecordStatus = request.getParameter("CustomerRecordStatus");
		
		//Active
		String customerFlagStatus=request.getParameter("CustomerFlagStatus");
		
		
		String modifiedDate = new Date().toString();		
		//Current Logged In user.....................................................
		String modifiedBy = request.getParameter("UserName");
		
	
		
		
		
		//Wrap data
		Customer oldCustomer = new Customer(customerCode,customerName,customerAddress1,customerAddress2,customerPinCode,customerEmail,
				customerContactNumber,customerPrimaryContactPerson,customerRecordStatus,customerFlagStatus,modifiedDate,
				modifiedBy);
		
		
		//get H-factory
		//CustomerDao dao = new CustomerDbUtil(factory);
		CustomerDao dao = new CustomerDbUtil(factory);
		
		//update db
		Customer theCustomer = dao.updateCustomer(oldCustomer);
		
	
		//GetSession
		httpSession = request.getSession();
		
		//To jsp
		request.setAttribute("UPDATED_CUSTOMER", theCustomer);
		
		String page = "/single-view-jsp.jsp";
		pageRequestDispatcher(request, response, page);
		
	}
	
	
	
}

