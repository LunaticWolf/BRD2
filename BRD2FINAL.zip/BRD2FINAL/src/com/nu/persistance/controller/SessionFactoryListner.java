package com.nu.persistance.controller;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.hibernate.SessionFactory;

import com.nu.persistance.Connection.HibernateSessionFactory;



public class SessionFactoryListner implements ServletContextListener 
{


	private SessionFactory factory = null;

	public void contextInitialized(ServletContextEvent event) 
	{
		factory = HibernateSessionFactory.getSessionFactory();
		event.getServletContext().setAttribute("FACTORY", factory);

	}

	public void contextDestroyed(ServletContextEvent event) 
	{
		
		event.getServletContext().removeAttribute("FACTORY");
	
		if(factory!=null)
			factory.close();
	}

}

	

