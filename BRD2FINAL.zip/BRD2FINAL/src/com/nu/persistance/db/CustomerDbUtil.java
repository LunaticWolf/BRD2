package com.nu.persistance.db;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.nu.persistance.model.Customer;

public class CustomerDbUtil implements CustomerDao
{

	private SessionFactory factory = null;
	Customer customer = null;
	
	
	public CustomerDbUtil(SessionFactory factory) 
	{
		this.factory = factory;
	}
	
	
	
	
	

	//Add---------------------------------------------------------------------------------------------
	
	public Customer addCustomer(Customer customer)
	{
		Session session = factory.openSession();
		Transaction transaction = session.getTransaction();
		
		try
		{
			transaction.begin();	
			//Returns PK
			session.save(customer);
			//System.out.println("Customer Code"+customerCode);
			transaction.commit();
		}
		catch (HibernateException e) 
		{
			transaction.rollback();
			e.printStackTrace();
		} 
		
		finally
		{
			closeSession(session);
		}
		return customer;
	}
	
	
	
	
	
	
	
	
	
	//ViewAll---------------------------------------------------------------------------------------------------
	@SuppressWarnings("unchecked")
	@Override
	public List<Customer> getCustomers() 
	{
		List<Customer> customers = null;
		Session session = factory.openSession();
		Transaction transaction = session.getTransaction();
	
		try 
		{
			transaction.begin();
			Query query = session.createQuery("from Customer_18060163");
			customers = query.list();
			
			transaction.commit();
		} 


		catch (HibernateException e) 
		{
			e.printStackTrace();
		} 

		finally 
		{
			closeSession(session);

		}
		return customers;
	}


	
	
	
	//Get ID-----------------------------------------------------------------------------------------------------------
	//Get Customer by Code-Id
	public Customer getCustomerById(String theCustomerCode)
	{
		Session session = factory.openSession();
		Transaction transaction = session.getTransaction();
		Customer theCustomer = null;
		try
		{
			transaction.begin();
			
			theCustomer = (Customer) session.get(Customer.class, theCustomerCode);
			
			transaction.commit();
			
		}
		catch (HibernateException e) 
		{
			transaction.rollback();
			e.printStackTrace();
		} 
		
		finally
		{
			closeSession(session);
		}
		return theCustomer;
	}	
	
	
	
	

	
	
	
	
	//Update--------------------------------------------------------------------------------------------------------
	public Customer updateCustomer(Customer oldCustomer)
	{
		Session session = factory.openSession();
		Transaction transaction = session.getTransaction();
		Customer theCustomer = null;
		try
		{
			transaction.begin();
			theCustomer = (Customer) session.get(Customer.class,oldCustomer.getCustomerCode());
			
			theCustomer.setCustomerName(oldCustomer.getCustomerName());
			theCustomer.setCustomerAddress1(oldCustomer.getCustomerAddress1());
			theCustomer.setCustomerAddress2(oldCustomer.getCustomerAddress2());
			theCustomer.setCustomerPinCode(oldCustomer.getCustomerPinCode());
			theCustomer.setCustomerEmail(oldCustomer.getCustomerEmail());
			theCustomer.setCustomerContactNumber(oldCustomer.getCustomerContactNumber());
			theCustomer.setCustomerPrimaryContactPerson(oldCustomer.getCustomerPrimaryContactPerson());
			theCustomer.setCustomerRecordStatus(oldCustomer.getCustomerRecordStatus());
			theCustomer.setCustomerFlagStatus(oldCustomer.getCustomerFlagStatus());
		
			theCustomer.setModifiedDate(oldCustomer.getModifiedDate());
			theCustomer.setModifiedBy(oldCustomer.getModifiedBy());
			
			
			
			
			//Or..............
			/*
			Query query = session
					.createQuery("update Customer set customerName=:name, customerAddress1=:add1, customerAddress2=:add2,customerPinCode=:pincode,emailAddress=:email,contactNumber=:number,primaryContactPerson=:contactperson,flag=:Flag where customerCode=:custcode");
        

         query.setString("custcode", customer.getCustomerCode());
			query.setString("name",customer.getCustomerName());
          query.setString("add1",customer.getCustomerAddress1());
          query.setString("add2",customer.getCustomerAddress2());
          query.setString("pincode",customer.getCustomerPinCode());
          query.setString("email",customer.getCustomerEmail());
          query.setString("number",customer.getCustomerContactNumber());
          query.setString("contactperson",customer.getCustomerPrimaryContactPerson());
          query.setString("Flag",customer.getCustomerFlagStatus());
          query.executeUpdate();*/
			
			
			
			
			
			transaction.commit();
		}
		catch (HibernateException e) 
		{
			transaction.rollback();
			e.printStackTrace();
		} 
		
		finally
		{
			closeSession(session);
		}
		return theCustomer;
		
	}
	

	
	
	
	
	
	//Delete Customer------------------------------------------------------------------------------------------------
	public Customer deleteCustomer(Customer theCustomer)
	{
		Session session = factory.openSession();
		Transaction transaction = session.getTransaction();
	
		
		try
		{
			transaction.begin();
			
			session.delete(theCustomer);
			
			transaction.commit();
			
		}
		catch (HibernateException e) 
		{
			transaction.rollback();
			e.printStackTrace();
		} 
		
		finally
		{
			closeSession(session);
		}
		return theCustomer;
		
	}
	
	
	
	
	
	
	
	
	//H-Session Close--------------------------------------------------------------------------------------------------------
	private void closeSession(Session session) 
	{
		if (session != null)
			session.close();
	}



}
