package com.nu.persistance.db;

import java.util.List;

import com.nu.persistance.model.Customer;

public interface CustomerDao 
{	
	
	//Add
	public Customer addCustomer(Customer theCustomer);

	//View
	public List<Customer> getCustomers();
	public Customer getCustomerById(String theCustomerCode);

	//Delete
	public Customer deleteCustomer(Customer theCustomer);

    //Update
	public Customer updateCustomer(Customer oldCustomer);
	

}
