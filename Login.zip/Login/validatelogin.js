

//Login Form Validation ------------------------------------------------------------------
function validatelogin()
{
	var userId = document.forms["loginform"]["UserId"].value;
	var password = document.forms["loginform"]["Password"].value;


	if(!(userId.search(/[^a-zA-Z0-9]+/) === -1)) 
    {
    	alert("Invalid User ID");
    	return false;
    }

    if(userId==null || userId==" " || userId.length==5)
	{	
		alert("Invalid User ID");
		return false;
	}


	if(password.length < 6 )
	{
		alert("Invalid Password Length");
		return false;
	}

 }




//Register Form------------------------------------------------
//Password MisMatch-------------------------------------------------------------------


function validateRegistered()
{
	var username = document.getElementById('UserName').value;
    var password = document.getElementById('Password').value;
    var confirmpassword = document.getElementById('confirm_password').value


	   if(password.length<6)
	   {
	   	alert("Invalid Password Length");
	   }

	   if(!( password.search(/[^a-zA-Z0-9#$_@]+/) === -1))
	   {
	   	alert("Invalid Passsword content");
	   }

	   if (password == confirmpassword) 
   		{
    		document.getElementById('message').style.color = 'green';
    		document.getElementById('message').innerHTML = 'matching';
  		} 

  		else 
  		{
    		document.getElementById('message').style.color = 'red';
    		document.getElementById('message').innerHTML = 'not matching';
 		 }



 		 if (username=="" || username==null ||username.length<6 || (!(username.search(/[^a-zA-Z]+/) === -1))) 
 		 {
   			 document.getElementById('message').style.color = 'green';
   			 document.getElementById('message').innerHTML = 'Valid Name';
  		}

 		 else 
 		{
   			document.getElementById('message').style.color = 'red';
    		document.getElementById('message').innerHTML = 'Invalid Name';
  		}

  		if(username.length<6 || (!(username.search(/[^a-zA-Z]+/) === -1)))
  		{
  			alert("Invali Username");
  		}
}










function validateform()
{
  var username = document.getElementById('UserName').value;
  var password1 = document.getElementById('Password1').value;
  var password2 = document.getElementById('Password2').value;
  var newuserid = document.getElementById('NewUserId').value;
   
   var userid = document.getElementById('UserId').value

var password = document.getElementById('Password').value;

  if(username="" || username==null)
  {
    alert("Invalid User Name");
    return false;
  }

  if(!(username.search(/[^a-zA-Z0-9]+/) === -1)) 
    {
      alert("Invalid Customer Name");
      return false;
    }



    if(password1!=password2)
    {
      alert("password mis-match");
      return false;
    }

    if(newuserid.length!=7 || userid.length!=7)
    {
      alert("Invalid UserID: Length must be 7: only including a-zA-Z0-9 characters ");
      return false;
    }

     if(!(userid.search(/[^a-zA-Z0-9]+/) === -1))
     {
      alert("Invalid User ID");
      return false;
     } 

      if(!(newuserid.search(/[^a-zA-Z0-9]+/) === -1))
      {
        alert("Invalid User ID");
        return false;
      } 


      if(password.length!=6)
      {
          alert("Invalid Password Length");
          return false;
      }

}


