
//Captcha----------------------------------------------------------------------------
//Generate Captcha.................................................................................................
function Captcha()
{
                     var alpha = new Array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','1','2','3','4','5','6','7','8','9','0');
                     var i;
                     for (i=0;i<6;i++)
                     {
                       var a = alpha[Math.floor(Math.random() * alpha.length)];
                       var b = alpha[Math.floor(Math.random() * alpha.length)];
                       var c = alpha[Math.floor(Math.random() * alpha.length)];
                       var d = alpha[Math.floor(Math.random() * alpha.length)];
                       var e = alpha[Math.floor(Math.random() * alpha.length)];
                       var f = alpha[Math.floor(Math.random() * alpha.length)];
                       var g = alpha[Math.floor(Math.random() * alpha.length)];
                      }
                    
                    var code = a + ' ' + b + ' ' + ' ' + c + ' ' + d + ' ' + e + ' '+ f + ' ' + g;
                    document.getElementById("mainCaptcha").value = code
}



//VAlidateCaptcha--------------------------------------------------------------------------------------
function ValidCaptcha()
{
  var string1 = removeSpaces(document.getElementById('mainCaptcha').value);
  var string2 = removeSpaces(document.getElementById('txtInput').value);
  if (string1 == string2)
  {
    return alert("Test Verified. You can now Register Yourself.");
  }
  else{        
    return alert("Incorrect Captcha!! Re-Enter the Captcha Code, Please!");
  }
}



function removeSpaces(string)
{
  return string.split(' ').join('');
}




//get ID----------------------------------------------------------------------------------------------
function generateID()
{
  var alpha = new Array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','1','2','3','4','5','6','7','8','9','0');
                     var i;
             for(i=0;i<6;i++)
             {

                      var a = alpha[Math.floor(Math.random() * alpha.length)];
                       var b = alpha[Math.floor(Math.random() * alpha.length)];
                       var c = alpha[Math.floor(Math.random() * alpha.length)];
                       var d = alpha[Math.floor(Math.random() * alpha.length)];
                       var e = alpha[Math.floor(Math.random() * alpha.length)];
                       var f = alpha[Math.floor(Math.random() * alpha.length)];
                       var g = alpha[Math.floor(Math.random() * alpha.length)];

             }                     

             var code = a + '' + b + '' + '' + c + '' + d + '' + e + ''+ f + '' + g;
             document.forms["myform2"]["NewUserId"].value = code;


}





//Validate Login And SignUp
//Login Form Validation ------------------------------------------------------------------
function validatelogin()
{
  var userId = document.forms["loginform"]["UserId"].value;
  var password = document.forms["loginform"]["Password"].value;


  if(!(userId.search(/[^a-zA-Z0-9]+/) === -1)) 
    {
      alert("Invalid User ID");
      return false;
    }

    if(userId==null || userId==" " || userId.length==5)
  { 
    alert("Invalid User ID");
    return false;
  }


  if(password.length < 6 )
  {
    alert("Invalid Password Length");
    return false;
  }

 }


 //Register Form.............


 var checkname = function()
{
  var username = document.forms["myform2"]["UserName"].value;
  

  if((username.search(/[^a-zA-Z0-9]+/) === -1))
  {
    document.getElementById('message').style.color = 'green';
        document.getElementById('message').innerHTML = 'Valid';
        
  }
  else
  {
    document.getElementById('message').style.color = 'red';
        document.getElementById('message').innerHTML = 'invalid';
  }


} 

var checkpassword = function()
{
  var password1 = document.forms["myform2"]["Password"].value;
  var password2 = document.forms["myform2"]["confirm_password"].value;

  if(password1!=password2)
  {
    document.getElementById('message1').style.color = 'red';
    document.getElementById('message1').innerHTML = 'Password Mis-Match';
  }
  else
  {
    document.getElementById('message1').style.color = 'green';
    document.getElementById('message1').innerHTML = 'matching';

  }
}




//validate register form 
var validateRegister = function()
{
  var username = document.forms["myform2"]["UserName"].value;
  var password = document.forms["myform2"]["Password"].value;

  if(username == " " || username == null)
  {
    alert("Enter UserName");
  }

  if(password.length < 6)
  {
    alert("Password Length Too Short..");
  }
}