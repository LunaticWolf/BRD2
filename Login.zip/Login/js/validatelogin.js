function validatelogin()
{
	var userId = document.forms["loginform"]["UserId"].value;
	var password = document.forms["loginform"]["Password"].value;


	if(!(userId.search(/[^a-zA-Z0-9]+/) === -1)) 
    {
    	alert("Invalid User ID");
    	return false;
    }

    if(userId==null || userId==" " || userId.length<4)
	{	
		alert("Invalid User ID");
		return false;
	}


	if(password.length < 6 )
	{
		alert("Invalid Password Length");
		return false;
	}

 }
