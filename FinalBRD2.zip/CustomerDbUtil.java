package com.nucleus.brd2;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;




public class CustomerDbUtil
{
	
	//Step 1--> Initialize Connection Object;
	private static DataSource datasource;
	
	public CustomerDbUtil(javax.sql.DataSource datasource2) {
		// TODO Auto-generated constructor stub
	}



	//Step 2--> Define Parametric Constructor;
	public void DataSource(DataSource thedatasource)
	{
		datasource = thedatasource;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//Multiple View
	//Step3--> define Method
	public List<Customer> getCustomer() throws SQLException
	{
		//Step 3.1 --> Get List
		List<Customer> customers = new ArrayList<>();
		
		//Step 3.2--> Get DB-Essentials SQL-Utils
		Connection myConn = null;
		Statement myStmt = null;
		ResultSet myRs = null;
		
		
		//Step 3.3 --> Get List
		try
		{
			//Step 3.3.1--> Get Connection
			myConn = (Connection) datasource.getConnection();
			
			//Step 3.3.2--> Create SQL Query
		   String sql = "Select * from <table-name>";
		   
		   
		   	//Step 3.3.3--> Create Statement
		   myStmt = (Statement) myConn.createStatement();
		   
		   
		   	//Step 3.3.4--> get Result Set
			myRs = myStmt.executeQuery(sql);
			
			
			//Step 3.3.5--> Process Result Set for data retrieval
			while(myRs.next())
			{
				int customerId = myRs.getInt("id");
				
				String customerCode = myRs.getString("customer_code");
				String customerName = myRs.getString("customer_name");
				String customerAddress1 = myRs.getString("customer_address1");
				String customerAddress2 = myRs.getString("customer_address2");
				String customerPincode = myRs.getString("customer_pincode");
				String customerEmail = myRs.getString("customer_email");
				String customerContactNumber = myRs.getString("customer_contact_number");
				String customerPrimaryContactPerson = myRs.getString("customer_primary_contact_person");
				String customerRecordStatus = myRs.getString("customer_record_status");
				String customerFlag = myRs.getString("customer_flag_status");
				
				String createdDate = myRs.getString("created_date");
				String createdBy = myRs.getString("created_by");
				String modifiedDate = myRs.getString("modified_date");
				String modifiedBy = myRs.getString("modified_by");
				String authorizedDate = myRs.getString("authorized_date");
				String authorizedBy = myRs.getString("authorized_by");
				
				
				
				
				//Step 3.3.6--> Customer Object To Pass the values to the List
				Customer tempCustomer = new Customer(customerId, customerCode, customerName, customerAddress1,
						 customerAddress2, customerPincode, customerEmail, customerContactNumber,
						 customerPrimaryContactPerson, customerRecordStatus, customerFlag, createdDate,
						 createdBy, modifiedDate, modifiedBy, authorizedDate, authorizedBy);
				
				
				
				//Step 3.3.7--> Customer fields added to the list-customers
				customers.add(tempCustomer);
				
			}	
				return customers;
			
		}
			
			catch(SQLException e)
			{
				System.out.println("SQL Exception Encountered While Displaying Data..- getCustomer()");
				e.printStackTrace();
			}
			
            //Step --> Close All Connection			
			finally
			{
			   close(myConn, myStmt, myRs);
			   //myConn will still be avaliable for others to Connect
			}
	
		return customers;
			
		
		
	}



	private void close(Connection myConn, Statement myStmt, ResultSet myRs) throws SQLException 
	{
		if(myConn!=null)
			myConn.close();
		
		if(myStmt!=null)
			myStmt.close();
		
		if(myRs!=null)
			myRs.close();
		
	}


	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//Servlet Method Extended
    //ADD
	public void addCustomer(Customer theCustomer) throws SQLException 
	
	{
		//initialize database obj's
		Connection myConn = null;
		PreparedStatement myStmt = null;
		ResultSet myRs = null;
		
		
		
		try
		{
			//Create Query
			myConn=(Connection) datasource.getConnection();
			
			//Query
			String sql= "insert into " + "(customerCode, customerName, customerAddress1,\r\n" + 
					"				 customerAddress2, customerPincode, customerEmail, customerContactNumber,\r\n" + 
					"				 customerPrimaryContactPerson, customerRecordStatus, customerFlag,  createdDate,\r\n" + 
					"				 createdBy, modifiedDate, modifiedBy, authorizedDate, authorizedBy)" +
					"values(?, ?, ? , ?, ?, ?, ?, ?, ?, ?, ?, ? , ?, ?, ?, ?)";
			
			//Statement
			myStmt = (PreparedStatement) myConn.prepareStatement(sql);
			
			
			//set Param values --added to database
			myStmt.setString(1, theCustomer.getCustomerCode());
			myStmt.setString(2, theCustomer.getCustomerName());
			myStmt.setString(3, theCustomer.getCustomerAddress1());
			myStmt.setString(4, theCustomer.getCustomerAddress2());
			myStmt.setString(5, theCustomer.getCustomerPincode());
			myStmt.setString(6, theCustomer.getCustomerEmail());
			myStmt.setString(7, theCustomer.getCustomerContactNumber());
			myStmt.setString(8, theCustomer.getCustomerPrimaryContactPerson());
			myStmt.setString(9, theCustomer.getCustomerRecordStatus());
			myStmt.setString(10, theCustomer.getCustomerFlag());
			
			
			myStmt.setString(11, theCustomer.getCreatedDate());
			myStmt.setString(12, theCustomer.getCreatedBy());
			myStmt.setString(13, theCustomer.getModifiedDate());
			myStmt.setString(14, theCustomer.getModifiedBy());
			myStmt.setString(15, theCustomer.getAuthorizedDate());
			myStmt.setString(16, theCustomer.getAuthorizedBy());
			
			
			myStmt.execute();
			
		}
		catch(SQLException e)
		{
			System.out.println("Couldn't Add..");
			e.printStackTrace();
		}
		finally
		{
			close(myConn,myStmt, null);
		}
				
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//Single View Record
	public void viewCustomer(String theCustomerId) throws SQLException 
	{
		
		//initialize database obj's
				Connection myConn = null;
				PreparedStatement myStmt = null;
				ResultSet myRs = null;
				
				
				
				try
				{
					//retrieved id from user
					int customerId = Integer.parseInt(theCustomerId);
					
					//Create Query
					myConn=(Connection) datasource.getConnection();
					
					//Query
					String sql = "select * from <table-name> where id = ?";
					
					myStmt = (PreparedStatement) myConn.prepareStatement(sql);
					
					//identified in db
					myStmt.setInt(1, customerId);
					
					//deleted
					myStmt.execute();
					
	             }
				
				catch(SQLException e)
				{
					System.out.println("Couldn't view Record");
					e.printStackTrace();
				}
				finally
				{
					close(myConn, myStmt, null);
				}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	
	//Delete Customer
	public void deleteCustomer(String theCustomerId) throws SQLException 
	{
		
		//initialize database obj's
				Connection myConn = null;
				PreparedStatement myStmt = null;
				ResultSet myRs = null;
				
				
				
				try
				{
					//retrieved id from user
					int customerId = Integer.parseInt(theCustomerId);
					
					//Create Query
					myConn=(Connection) datasource.getConnection();
					
					//Query
					String sql = "delete from <table-name> where id = ?";
					
					myStmt = (PreparedStatement) myConn.prepareStatement(sql);
					
					//identified in db
					myStmt.setInt(1, customerId);
					
					//deleted
					myStmt.execute();
					
	             }
				
				catch(SQLException e)
				{
					System.out.println("Couldn't delete record");
					e.printStackTrace();
				}
				finally
				{
					close(myConn, myStmt, null);
				}
	}




	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//pre-populated data
	public static Customer loadCustomer(String customerID) 
	{
		
		Customer theCustomer;
		
		Connection myConn = null;
		java.sql.PreparedStatement myStmt = null;
		ResultSet myRs = null;
		
		try
		{
			
			//ID int
			int theCustomerId = Integer.parseInt(customerID);
			
			
			//get connection
			myConn=(Connection) datasource.getConnection();
	
			
			//Query
			String sql = "Select * from <table> where id = ?";
			myStmt = myConn.prepareStatement(sql);
			myStmt.setInt(1, theCustomerId);
			
			//Result Set
			myRs = myStmt.executeQuery();
			
			//Process Result Set
			if(myRs.next())
			{
				String customerCode = myRs.getString("customer_code");
				String customerName = myRs.getString("customer_name");
				String customerAddress1 = myRs.getString("customer_address1");
				String customerAddress2 = myRs.getString("customer_address2");
				String customerPincode = myRs.getString("customer_pincode");
				String customerEmail = myRs.getString("customer_email");
				String customerContactNumber = myRs.getString("customer_contact_number");
				String customerPrimaryContactPerson = myRs.getString("customer_primary_contact_person");
				String customerRecordStatus = myRs.getString("customer_record_status");
				String customerFlag = myRs.getString("customer_flag_status");
				
				
				theCustomer = new Customer(theCustomerId, customerCode, customerName, customerAddress1, customerAddress2, customerPincode,customerEmail, 
						customerContactNumber,customerPrimaryContactPerson,customerRecordStatus, customerFlag );
			}
			
			return theCustomer;
			
		}
	}



	
	
	
	
	
	
	
	
	
	public void updateCustomers(Customer theCustomer) throws SQLException 
	{
		//initialize database obj's
				Connection myConn = null;
				PreparedStatement myStmt = null;
				ResultSet myRs = null;
				
				
				
				try
				{
					//Create Query
					myConn=(Connection) datasource.getConnection();
					
					//Query
					String sql= "update <table> " + "set customerCode =?, customerName=?, customerAddress1=?,\r\n" + 
							"				 customerAddress2=?, customerPincode=?, customerEmail=?, customerContactNumber=?,\r\n" + 
							"				 customerPrimaryContactPerson=?, customerRecordStatus=?, customerFlag=?,  createdDate=?,\r\n" + 
							"				 createdBy=?, modifiedDate=?, modifiedBy=?, authorizedDate=?, authorizedBy=? where id =?";
					
					//Statement
					myStmt = (PreparedStatement) myConn.prepareStatement(sql);
					
					
					//set Param values --added to database
					myStmt.setString(1, theCustomer.getCustomerCode());
					myStmt.setString(2, theCustomer.getCustomerName());
					myStmt.setString(3, theCustomer.getCustomerAddress1());
					myStmt.setString(4, theCustomer.getCustomerAddress2());
					myStmt.setString(5, theCustomer.getCustomerPincode());
					myStmt.setString(6, theCustomer.getCustomerEmail());
					myStmt.setString(7, theCustomer.getCustomerContactNumber());
					myStmt.setString(8, theCustomer.getCustomerPrimaryContactPerson());
					myStmt.setString(9, theCustomer.getCustomerRecordStatus());
					myStmt.setString(10, theCustomer.getCustomerFlag());
					
					
					myStmt.setString(11, theCustomer.getCreatedDate());
					myStmt.setString(12, theCustomer.getCreatedBy());
					myStmt.setString(13, theCustomer.getModifiedDate());
					myStmt.setString(14, theCustomer.getModifiedBy());
					myStmt.setString(15, theCustomer.getAuthorizedDate());
					myStmt.setString(16, theCustomer.getAuthorizedBy());
					myStmt.setInt(17, customerId);
					
					
					myStmt.execute();
					
				}
				catch(SQLException e)
				{
					System.out.println("Couldn't Add..");
					e.printStackTrace();
				}
				finally
				{
					close(myConn,myStmt, null);
				}
						
			}
			
			
	}
		
	




	
	

