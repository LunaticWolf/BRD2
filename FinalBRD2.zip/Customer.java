package com.nucleus.brd2;




//Model Layer
//Pojo Class
public class Customer 
{
	
	//Field Declaration..--------------------------------------------------------------------------//
	private int customerId;
	
	private String customerCode;
	private String customerName;
	private String customerAddress1;
	private String customerAddress2;
	private String customerPincode;	
	private String customerEmail;
	private String customerContactNumber;
	private String customerPrimaryContactPerson;
	private String customerRecordStatus;
	private String customerFlag;
		
	
	private String createdDate;
	private String createdBy;
	private String modifiedDate;
	private String modifiedBy;
	private String authorizedDate;
	private String authorizedBy;
	
	
	
	
	
	
	//Constructor..------------------------------------------------------------------------------//
	//With Customer ID...........................................................................
	public Customer(int customerId, String customerCode, String customerName, String customerAddress1,
			String customerAddress2, String customerPincode, String customerEmail, String customerContactNumber,
			String customerPrimaryContactPerson, String customerRecordStatus, String customerFlag, String createdDate,
			String createdBy, String modifiedDate, String modifiedBy, String authorizedDate, String authorizedBy) {
		super();
		this.customerId = customerId;
		this.customerCode = customerCode;
		this.customerName = customerName;
		this.customerAddress1 = customerAddress1;
		this.customerAddress2 = customerAddress2;
		this.customerPincode = customerPincode;
		this.customerEmail = customerEmail;
		this.customerContactNumber = customerContactNumber;
		this.customerPrimaryContactPerson = customerPrimaryContactPerson;
		this.customerRecordStatus = customerRecordStatus;
		this.customerFlag = customerFlag;
		this.createdDate = createdDate;
		this.createdBy = createdBy;
		this.modifiedDate = modifiedDate;
		this.modifiedBy = modifiedBy;
		this.authorizedDate = authorizedDate;
		this.authorizedBy = authorizedBy;
	}



    //Without Customer ID...........................................................................
	public Customer(String customerCode, String customerName, String customerAddress1, String customerAddress2,
			String customerPincode, String customerEmail, String customerContactNumber,
			String customerPrimaryContactPerson, String customerRecordStatus, String customerFlag, String createdDate,
			String createdBy, String modifiedDate, String modifiedBy, String authorizedDate, String authorizedBy) {
		super();
		this.customerCode = customerCode;
		this.customerName = customerName;
		this.customerAddress1 = customerAddress1;
		this.customerAddress2 = customerAddress2;
		this.customerPincode = customerPincode;
		this.customerEmail = customerEmail;
		this.customerContactNumber = customerContactNumber;
		this.customerPrimaryContactPerson = customerPrimaryContactPerson;
		this.customerRecordStatus = customerRecordStatus;
		this.customerFlag = customerFlag;
		this.createdDate = createdDate;
		this.createdBy = createdBy;
		this.modifiedDate = modifiedDate;
		this.modifiedBy = modifiedBy;
		this.authorizedDate = authorizedDate;
		this.authorizedBy = authorizedBy;
	}



	

	
	
	
	
	
	
	public Customer(int customerId, String customerCode, String customerName, String customerAddress1,
			String customerAddress2, String customerPincode, String customerEmail, String customerContactNumber,
			String customerPrimaryContactPerson, String customerRecordStatus, String customerFlag) {
		super();
		this.customerId = customerId;
		this.customerCode = customerCode;
		this.customerName = customerName;
		this.customerAddress1 = customerAddress1;
		this.customerAddress2 = customerAddress2;
		this.customerPincode = customerPincode;
		this.customerEmail = customerEmail;
		this.customerContactNumber = customerContactNumber;
		this.customerPrimaryContactPerson = customerPrimaryContactPerson;
		this.customerRecordStatus = customerRecordStatus;
		this.customerFlag = customerFlag;
	}



	//Getters..---------------------------------------------------------------------------------------//
	public int getCustomerId() {
		return customerId;
	}



	public String getCustomerCode() {
		return customerCode;
	}



	public String getCustomerName() {
		return customerName;
	}



	public String getCustomerAddress1() {
		return customerAddress1;
	}



	public String getCustomerAddress2() {
		return customerAddress2;
	}



	public String getCustomerPincode() {
		return customerPincode;
	}



	public String getCustomerEmail() {
		return customerEmail;
	}



	public String getCustomerContactNumber() {
		return customerContactNumber;
	}



	public String getCustomerPrimaryContactPerson() {
		return customerPrimaryContactPerson;
	}



	public String getCustomerRecordStatus() {
		return customerRecordStatus;
	}



	public String getCustomerFlag() {
		return customerFlag;
	}



	public String getCreatedDate() {
		return createdDate;
	}



	public String getCreatedBy() {
		return createdBy;
	}



	public String getModifiedDate() {
		return modifiedDate;
	}



	public String getModifiedBy() {
		return modifiedBy;
	}



	public String getAuthorizedDate() {
		return authorizedDate;
	}



	public String getAuthorizedBy() {
		return authorizedBy;
	}



	
	
	
	
	
	//Setters..-------------------------------------------------------------------------------------//
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}



	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}



	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}



	public void setCustomerAddress1(String customerAddress1) {
		this.customerAddress1 = customerAddress1;
	}



	public void setCustomerAddress2(String customerAddress2) {
		this.customerAddress2 = customerAddress2;
	}



	public void setCustomerPincode(String customerPincode) {
		this.customerPincode = customerPincode;
	}



	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}



	public void setCustomerContactNumber(String customerContactNumber) {
		this.customerContactNumber = customerContactNumber;
	}



	public void setCustomerPrimaryContactPerson(String customerPrimaryContactPerson) {
		this.customerPrimaryContactPerson = customerPrimaryContactPerson;
	}



	public void setCustomerRecordStatus(String customerRecordStatus) {
		this.customerRecordStatus = customerRecordStatus;
	}



	public void setCustomerFlag(String customerFlag) {
		this.customerFlag = customerFlag;
	}



	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}



	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}



	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}



	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}



	public void setAuthorizedDate(String authorizedDate) {
		this.authorizedDate = authorizedDate;
	}



	public void setAuthorizedBy(String authorizedBy) {
		this.authorizedBy = authorizedBy;
	}



	
	
	
	//To String---------------------------------------------------------------------------------------//
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerCode=" + customerCode + ", customerName="
				+ customerName + ", customerAddress1=" + customerAddress1 + ", customerAddress2=" + customerAddress2
				+ ", customerPincode=" + customerPincode + ", customerEmail=" + customerEmail
				+ ", customerContactNumber=" + customerContactNumber + ", customerPrimaryContactNumber="
				+ customerPrimaryContactPerson + ", customerRecordStatus=" + customerRecordStatus + ", customerFlag="
				+ customerFlag + ", createdDate=" + createdDate + ", createdBy=" + createdBy + ", modifiedDate="
				+ modifiedDate + ", modifiedBy=" + modifiedBy + ", authorizedDate=" + authorizedDate + ", authorizedBy="
				+ authorizedBy + "]";
	}
	
}
