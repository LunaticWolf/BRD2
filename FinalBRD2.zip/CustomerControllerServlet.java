package com.nucleus.brd2;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;


@WebServlet("/CustomerControllerServlet")
public class CustomerControllerServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
	
	
	
// Step 1 --> Define pojo-db-Util Object
		   private CustomerDbUtil customerdbutil;
		   
//Step 2 --> Define Resource
		   @Resource(name="jdbc/Servlets")
		   private DataSource datasource;
			
//Step 3--> 
//override init method
		   @Override
		   public void init() throws ServletException
		   {
			   super.init();
			   
			   customerdbutil = new CustomerDbUtil(datasource);
		   }
		   
		   
		   
  //Default
		    public CustomerControllerServlet() 
		    {
		        super();
    }

    
    
    
    
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	
	
	
	
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{		
	
	try
		{
			
			//Step 4--> Call Servlet Method - List
		
		
			String theCommand = "ADD";
			//String theCommand = request.getParameter("Command");
			
		
			
			//from nav bar
			if(theCommand==null)
			{
				theCommand = "VIEW";
			}
			
			
			
			switch(theCommand)
			{
				
				//Multiple View
				//LIST
				case "VIEW": listCustomer(request,response);
			                 break;
				 
			   /* //Single View             
				case "VIEW": viewCustomer(request,response);
	                         break;*/
	             
	          /*   //Add Customer
				case "ADD" : addCustomer(request, response);
				             break;*/
				             
			  //Update Customer
			    case "UPDATE": updateCustomer(request,response);
				             break;				              
			 
			/*  //pre-populate fields               
			  case "LOAD" : loadCustomer(request,response);
			                 break;
			  */
			                 
			  //delete data               
			  case "DELETE": delete(request,response);
			                 break;
			   
			  //Multiple View               
			  default: listCustomer(request,response);
			}
			
			
				
		}
		catch(Exception e)
		{
			
			System.out.println("Command Error--> list(request,response)");
			e.printStackTrace();
		}
	}


	
	




	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


	//Methods Assoiciated to Switch Cases above--^
	//Servlet Display Method
	//MultiDisplay
	private void listCustomer(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, SQLException 
	{
	    //Step --> 5
		//5.1-> get list
		List<Customer> theCustomers = customerdbutil.getCustomer();
	    
		//5.2--> associate list to request object;
		request.setAttribute("CUSTOMER_LIST", theCustomers);
		
		//5.3--> Dispatch Request
		RequestDispatcher requestdispatcher = request.getRequestDispatcher("/list-diaplay.jsp");
		requestdispatcher.forward(request, response);
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	//Servlet ADD Method
    private void addCustomer(HttpServletRequest request, HttpServletResponse response) throws SQLException 
    {
		
		//Read Data off the form
    	String customerCode = request.getParameter("CustomerCode");
    	String customerName = request.getParameter("CustomerName");
    	String customerAddress1 = request.getParameter("CustomerAddress1");
    	String customerAddress2 = request.getParameter("CustomerAddress2");
    	String customerPincode = request.getParameter("CustomerPincode");
    	String customerEmail = request.getParameter("CustomerEmail");
    	String customerContactNumber = request.getParameter("CustomerContactPerson");
    	String customerPrimaryContactPerson = request.getParameter("CustomerPrimaryContactPerson");
    	String customerRecordStatus = request.getParameter("CustomerRecordStatus");
    	String customerFlag = request.getParameter("CustomerFlag");
    	
    	String createdDate = new java.util.Date().toString();
    	String createdBy = request.getParameter("CustomerName");
    	String modifiedDate = "-";
    	String modifiedBy = "-";
    	String authorizedDate = "-";
    	String authorizedBy = "-";
    	
    	
    	
    	//Create Customer Object
    	Customer theCustomer = new Customer(customerCode, customerName, customerAddress1,
				 customerAddress2, customerPincode, customerEmail, customerContactNumber,
				 customerPrimaryContactPerson, customerRecordStatus, customerFlag, createdDate,
				 createdBy, modifiedDate, modifiedBy, authorizedDate, authorizedBy);
    	
    	
    	//Add Data to DB
    	customerdbutil.addCustomer(theCustomer);
    	
    	
    	
    	//To Display added data
    	//listCustomer(request,response);
    	
    	
	}
	
	
    
    
    
    
    
    
    //delete Customer - 
	private void delete(HttpServletRequest request, HttpServletResponse response) throws SQLException 
	{
		
		//get parameter
		String theCustomerId = request.getParameter("CustomerID");
		
		
		//Call DB
		customerdbutil.deleteCustomer(theCustomerId);;
		
		
		//Display List
		//listCustomer(request, response);
		
	}
    
    
    
    
    

	
	
	
	
	
	private void loadCustomer(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		//get id
		String customerID = request.getParameter("CustomerID");
		
		
		//get customer
		Customer theCustomer = CustomerDbUtil.loadCustomer(customerID);
		
		//to request object
		request.setAttribute("THE_CUSTOMER",theCustomer);
		
		
		//dispatched
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("/update-form.jsp");
		requestDispatcher.forward(request,response);
		
	}
	
	
	
	
	
	
	

	private void updateCustomer(HttpServletRequest request, HttpServletResponse response) 
	{
		//Read Data off the form
		String customerId = "";
    	String customerCode = request.getParameter("CustomerCode");
    	String customerName = request.getParameter("CustomerName");
    	String customerAddress1 = request.getParameter("CustomerAddress1");
    	String customerAddress2 = request.getParameter("CustomerAddress2");
    	String customerPincode = request.getParameter("CustomerPincode");
    	String customerEmail = request.getParameter("CustomerEmail");
    	String customerContactNumber = request.getParameter("CustomerContactPerson");
    	String customerPrimaryContactPerson = request.getParameter("CustomerPrimaryContactPerson");
    	String customerRecordStatus = request.getParameter("CustomerRecordStatus");
    	String customerFlag = request.getParameter("CustomerFlag");
    	
    	String createdDate ="";
    	String createdBy="";
    	String modifiedDate = new java.util.Date().toString();
    	String modifiedBy = request.getParameter("CustomerName");
    	String authorizedDate = "-";
    	String authorizedBy = "-";		
	
	
	
	//Object
    	Customer theCustomer = new Customer(customerId, customerCode, customerName, customerAddress1,
				 customerAddress2, customerPincode, customerEmail, customerContactNumber,
				 customerPrimaryContactPerson, customerRecordStatus, customerFlag, createdDate,
				 createdBy, modifiedDate, modifiedBy, authorizedDate, authorizedBy);
    	
    	
    	
    	
    	customerdbutil.updateCustomers(theCustomer);
    	
    	//display list 
    	//listCustomer(request,response);
    	
    	
	
	}
	
}






